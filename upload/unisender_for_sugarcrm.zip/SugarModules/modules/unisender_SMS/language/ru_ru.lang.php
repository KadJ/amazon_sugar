<?php
$mod_strings = array (
  /*
  'LBL_TEAM' => 'Teams',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  */

  'LBL_LIST_FORM_TITLE' => 'Список SMS',
  'LBL_MODULE_NAME' => 'SMS',
  'LBL_MODULE_TITLE' => 'SMS',
  'LBL_HOMEPAGE_TITLE' => 'Мои SMS',
  'LNK_NEW_RECORD' => 'Создать SMS',
  'LNK_LIST' => 'SMS',
  'LBL_SEARCH_FORM_TITLE' => 'Поиск SMS',

  /*
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  */
  
  'LBL_UNISENDER_SMS_SUBPANEL_TITLE' => 'SMS',
  'LBL_NEW_FORM_TITLE' => 'Новое SMS',
  'LBL_TYPE' => 'Тип',
  'LBL_PHONE_NUMBER' => 'Номер телефона',
  'LBL_API_MESSAGE' => 'API сообщение',
  'LBL_DELIVERY_STATUS' => 'Статус доставки',
  'LBL_PROVIDER' => 'Оператор',
  //'LBL_LIST_RELATED_TO_ID' => 'Related to'
);

