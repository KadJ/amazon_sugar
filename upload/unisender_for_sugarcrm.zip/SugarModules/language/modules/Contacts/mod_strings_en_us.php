<?php

$mod_strings = array_merge($mod_strings,
	array(
		// Layoutdefs
		'LBL_UNISENDER_SMS' => 'Unisender SMS',
		'LBL_UNISENDER_SMS_SUBPANEL_TITLE' => 'Unisender SMS',
	)
);
?>
