<?php

if (!isset($mod_strings)) { $mod_strings = array(); }

// header
$mod_strings['LBL_UNISENDER_CONFIG'] = 'Конфигурация Unisender Suite';

// config1 sub-header
$mod_strings['LBL_UNISENDER_CONFIG_LBL'] = 'Настройки API';
//
$mod_strings['LBL_UNISENDER_CONFIG_API_KEY'] = 'API key';
$mod_strings['LBL_UNISENDER_CONFIG_API_KEY_HELP'] = 'Ваш ключ доступа к API Unisender <a href="http://cp.unisender.com/ru/user_info">здесь</a>';

// config2 sub-header
$mod_strings['LBL_UNISENDER_CONFIG2_LBL'] = 'Настройки Cписков';
//
$mod_strings['LBL_UNISENDER_CONFIG_LIST_TRANSFER'] = 'Список рассылки для переноса существующих контактов в Unisender, см. <a href="./index.php?module=Administration&action=transfer">шаг 6</a>';
$mod_strings['LBL_UNISENDER_CONFIG_LIST_TRANSFER_HELP'] = 'Выбор из <a href="http://cp.unisender.com/ru/list_list">существующих списков</a> в Unisender';
// index.php?module=Administration
// ./index.php?module=Administration&action=transfer
//
$mod_strings['LBL_UNISENDER_CONFIG_LIST_ADD'] = 'Список рассылки для добавления новых контактов в Unisender';
$mod_strings['LBL_UNISENDER_CONFIG_LIST_ADD_HELP'] = 'Можно выбрать другой список. И, например, использовать для приветственной рассылки.';
//
$mod_strings['LBL_UNISENDER_CONFIG_SENDER'] = 'От кого (только для СМС)';
$mod_strings['LBL_UNISENDER_CONFIG_SENDER_HELP'] = 'Можно использовать, например, SugarCRM вместо +79031234567/79031234567';

//
$mod_strings['LBL_RESTORE_BUTTON_LABEL'] = 'Восстановить';
