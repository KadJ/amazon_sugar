<?php

if (!isset($mod_strings)) { $mod_strings = array(); }

// Layoutdefs
$mod_strings['LBL_UNISENDER_SMS'] = 'UniSender SMS';

// group
$mod_strings['LBL_UNISENDER'] = 'UniSender Suite';
$mod_strings['LBL_UNISENDER_DESC'] = 'E-mail marketing and mass SMS sending';

// 1
$mod_strings['LBL_UNISENDER_CONFIG'] = '1. API key from UniSender';
$mod_strings['LBL_UNISENDER_CONFIG_DESC'] = 'API key for integration';

// 2
$mod_strings['LBL_UNISENDER_CONFIG2'] = '2. UniSender lists';
$mod_strings['LBL_UNISENDER_CONFIG2_DESC'] = 'Lists for integration';

// 2
$mod_strings['LBL_UNISENDER_MODULES'] = '3. SMS & Modules Relationship';
$mod_strings['LBL_UNISENDER_MODULES_DESC'] = 'Customize the related modules for SMS module';

// 3
$mod_strings['LBL_UNISENDER_FIELDS'] = '4. Field selector';
$mod_strings['LBL_UNISENDER_FIELDS_DESC'] = 'Select phone numbers that are SMS capable';

// 4
$mod_strings['LBL_UNISENDER_BALANCE'] = '5. Account balance';
$mod_strings['LBL_UNISENDER_BALANCE_DESC'] = 'Check your available balance';

// 5
/*
$mod_strings['LBL_UNISENDER_MACRO'] = 'SMS шаблоны';
$mod_strings['LBL_UNISENDER_MACRO_DESC'] = 'Создание шаблоново для SMS';
*/

// 6
$mod_strings['LBL_UNISENDER_TRANSFER'] = '6. Tranfer existing Contacts to UniSender';
$mod_strings['LBL_UNISENDER_TRANSFER_DESC'] = 'Tranfer all existing Contacts to designated UniSender list';


////////////////////////////////////////////////////////////////////////////////////////

// smsProvider

// MSG's

// 1
$mod_strings['LBL_ERROR'] = 'error'; // Unisender code
// 2 MSG_UNVERIFIED
$mod_strings['LBL_UNABLE_TO_AUTHENTICATE'] = 'Unable to aunthenticate your Account ID. Please try again or contact UniSender for verification.';

// LBL's

// 1
$mod_strings['LBL_NOT_SPECIFIED_API_KEY'] = 'You have not specified an SMS gateway for this purpose.';
$mod_strings['LBL_CLICK'] = 'Click';
$mod_strings['LBL_HERE'] = 'here';
$mod_strings['LBL_TO_SETUP_YOUR_ACCOUNT'] = 'to setup your UniSender account.';

// 2
$mod_strings['LBL_SMS_BALANCE'] = 'Balance';
$mod_strings['LBL_SMS_BALANCE2'] = '<br>Your balance <strong>'; //
$mod_strings['LBL_SMS_BALANCE3'] = 'To add credits to your account follow to <a href="http://cp.unisender.com/en/account_balance">UniSender site</a>'; //


