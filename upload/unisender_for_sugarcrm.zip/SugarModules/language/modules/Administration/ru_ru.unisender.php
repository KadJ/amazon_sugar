<?php

if (!isset($mod_strings)) { $mod_strings = array(); }

// Layoutdefs
$mod_strings['LBL_UNISENDER_SMS'] = 'UniSender SMS';

// group
$mod_strings['LBL_UNISENDER'] = 'UniSender Suite';
$mod_strings['LBL_UNISENDER_DESC'] = 'E-mail маркетинг и массовая рассылка SMS';

// 1
$mod_strings['LBL_UNISENDER_CONFIG'] = '1. Ключ API UniSender';
$mod_strings['LBL_UNISENDER_CONFIG_DESC'] = 'API key для интеграции';

// 2
$mod_strings['LBL_UNISENDER_CONFIG2'] = '2. Списки UniSender';
$mod_strings['LBL_UNISENDER_CONFIG2_DESC'] = 'Списки для интеграции';

// 2
$mod_strings['LBL_UNISENDER_MODULES'] = '3. Привязка модулей для SMS';
$mod_strings['LBL_UNISENDER_MODULES_DESC'] = 'Выбор модули для SMS';

// 3
$mod_strings['LBL_UNISENDER_FIELDS'] = '4. Привязка полей (модулей) для SMS';
$mod_strings['LBL_UNISENDER_FIELDS_DESC'] = 'Выбор полей (модулей) для SMS';

// 4
$mod_strings['LBL_UNISENDER_BALANCE'] = '5. Баланс счёта';
$mod_strings['LBL_UNISENDER_BALANCE_DESC'] = 'Проверка баланса счёта';

// 5
/*
$mod_strings['LBL_UNISENDER_MACRO'] = 'SMS шаблоны';
$mod_strings['LBL_UNISENDER_MACRO_DESC'] = 'Создание шаблоново для SMS';
*/

// 6
$mod_strings['LBL_UNISENDER_TRANSFER'] = '6. Перенос контактов в UniSender';
$mod_strings['LBL_UNISENDER_TRANSFER_DESC'] = 'Перенести все существующие контакты в список рассылки UniSender';


////////////////////////////////////////////////////////////////////////////////////////

// smsProvider

// MSG's

// 1
$mod_strings['LBL_ERROR'] = 'error'; // Unisender code
// 2 MSG_UNVERIFIED
$mod_strings['LBL_UNABLE_TO_AUTHENTICATE'] = 'Ошибка авторизации API.'; //'Unable to aunthenticate your Account ID. Please try again or contact Unisender for verification.';

// LBL's

// 1
$mod_strings['LBL_NOT_SPECIFIED_API_KEY'] = 'Вы не указали ключ API.'; //You have not specified an SMS gateway for this purpose. 
$mod_strings['LBL_CLICK'] = 'Перейдите'; //Click
$mod_strings['LBL_HERE'] = 'сюда'; // here
$mod_strings['LBL_TO_SETUP_YOUR_ACCOUNT'] = 'чтобы настроить UniSender Suite.'; //to setup your gateway account.

// 2
$mod_strings['LBL_SMS_BALANCE'] = 'Баланс'; //Balance
$mod_strings['LBL_SMS_BALANCE2'] = '<br>Ваш баланс <strong>'; //
$mod_strings['LBL_SMS_BALANCE3'] = 'Для пополнения счёта перейдите <a href="http://cp.unisender.com/ru/account_balance">на сайт UniSender</a>'; //


