<?php

$app_list_strings['moduleList']['unisender_SMS'] = 'SMS';
$app_list_strings['type_list']['inbound'] = 'inbound'; // inbound
$app_list_strings['type_list']['outbound'] = 'outbound'; // outbound

$app_list_strings['delivery_status_list']['SENT'] = 'Sent';
$app_list_strings['delivery_status_list']['FAILED'] = 'Failed';
$app_list_strings['delivery_status_list']['ERROR'] = 'Error';
$app_list_strings['delivery_status_list']['RECEIVED'] = 'Received'; 

$app_list_strings['campaign_type_dom'][''] = ''; 
$app_list_strings['campaign_type_dom']['Email'] = 'Email'; 
$app_list_strings['campaign_type_dom']['Mail'] = 'Mail'; 
$app_list_strings['campaign_type_dom']['NewsLetter'] = 'NewsLetter'; 
$app_list_strings['campaign_type_dom']['Print'] = 'Print'; 
$app_list_strings['campaign_type_dom']['Radio'] = 'Radio';
//nonupgradesafe2
$app_list_strings['campaign_type_dom']['SMS'] = 'UniSender SMS'; 
//
$app_list_strings['campaign_type_dom']['Telesales'] = 'Telesales'; 
$app_list_strings['campaign_type_dom']['Television'] = 'Television'; 
$app_list_strings['campaign_type_dom']['Web'] = 'Web';  

/////////////////////////////////////////////////////////////////////////////////////////////

// custom/fieldFormat/sms_phone_fields.php
$app_strings['LBL_CLICK_TO_SEND_SMS'] = 'Click to send an SMS. Opening the editor may take a moment. Please give it some time.'; //

// nonupgradesafe/include/ListView/6.2.4/ListViewDisplay.php
$app_strings['LBL_LISTVIEW_COMPOSE_SMS_UNISENDER'] = 'UniSender SMS'; // UniSender SMS

// modules/Administration/smsProvider.php
$app_strings['LBL_PRESS_ESC_OR_CLICK_GRAY_AREA'] = 'Press ESC key or click the gray area to close this message.'; // 
$app_strings['LBL_SAVE'] = 'Save'; // 

// modules/Administration/customUsage.php
$app_strings['LBL_CLICK_REPAIR_TO_APPLY'] = 'Click Repair button to apply your customization.'; // 
$app_strings['LBL_SMS_MODULES_RELATIONSHIP'] = 'SMS & Module Relationships'; // 
$app_strings['LBL_MOVE_MODULE_RIGHT'] = 'Move a module to the right panel to create a relationship with SMS'; // 
$app_strings['LBL_CLICK_SELECT_DESELECT'] = 'Click to select or deselect'; //  

// modules/Administration/unisender_customUsage/javascript/customUsage.js
//$app_strings['LBL_CLICK_SELECT_DESELECT']

// modules/Administration/unisender_smsPhone/sms_editor.php
$app_strings['LBL_RECIPIENTS'] = 'Recipients'; //  
$app_strings['LBL_CLICK_TO_REMOVE'] = 'Click to remove'; // 
$app_strings['LBL_YOU_REMOVED_ALL_RECIPIENTS'] = 'You removed all recipients. <br>Press ESC key or click the gray area to close this message.'; // 
$app_strings['LBL_PHONE_NUMBER'] = 'Phone Number'; // 
$app_strings['LBL_COUNTRY_CODE'] = 'country code'; // 
$app_strings['LBL_NUMBER'] = 'number'; // 
$app_strings['LBL_TEMPLATE'] = 'Template'; // 
$app_strings['LBL_MESSAGE'] = 'Message '; //  
$app_strings['LBL_LIMIT_YOUR_MESSAGE'] = 'Limit your message up to 140 characters only.'; // 
$app_strings['LBL_PRESS_ESC_TO_CLOSE'] = 'Press ESC key to close.'; // 
$app_strings['LBL_SEND'] = 'Send'; // 

// modules/Administration/smsPhone.php
$app_strings['LBL_SELECT_FIELDS_LOADED'] = 'Selected fields were successfully loaded for customization.'; // 
//$app_strings['LBL_SELECT_FIELDS_LOADED'] = 'To effect the changes, click <Strong>Repair</strong> button.';
 // To effect the changes, click <Strong>Repair</strong> button.
$app_strings['LBL_FIELD_SELECTOR'] = 'Field Selector'; // 
$app_strings['LBL_SELECT_RELATED_MODULE'] = 'Select a related module'; // 
$app_strings['LBL_NEED_TO_SET_RELATIONSHIPS_BETWEEN_SMS'] = 'You may need to set a relationship between the SMS module and the other modules. '; // 
$app_strings['LBL_CLICK'] = 'Click '; // 
$app_strings['LBL_HERE'] = 'here'; // here
$app_strings['LBL_TO_SET_RELATIONSHIP'] = ' to set the relationship.</p>'; //  
$app_strings['LBL_TO_CONFIGURE_FIELD_AS_SMS'] = 'To configure a field as an sms number, move the field to the right panel'; // 
$app_strings['LBL_SELECT_RELATED_MODULE'] = 'Please select a related module.'; // 
$app_strings['LBL_REPAIR'] = 'Repair'; // Repair

// modules/Administration/unisender_smsPhone/javascript/smsPhone.js
$app_strings['LBL_TIP'] = '<p>Please key in the full number without any separator in the following format<div align=center>&lt; COUNTRY CODE &gt;&lt; PHONE NUMBER &gt;</div></p><p>Example:</p><table><tr><td>Russia (+7) </td><td>&nbsp;&nbsp;<strong>903 1234567</strong></td></tr></table>';
$app_strings['LBL_SENDING'] = 'Sending... Please wait!'; // 
//2do
$app_strings['LBL_CLICL_OK_TO_CLEAR_CUSTOMIZATION'] = 'Click OK to clear phone field customization for '; // Click OK to clear phone field customization for 
//2do
$app_strings['LBL_YOU_NEED_TO_SELECT_FIELD'] = 'You need to select a field and enter an SMS macro string.'; // You need to select a field and enter an SMS macro string.
//2do
$app_strings['LBL_LOADING'] = 'Loading...'; // 
//2do
$app_strings['LBL_140_CHARS'] = '/140 characters.'; // /140 characters. 
//2do
$app_strings['LBL_YOU_MUST_HAVE_1_RECIPIENT'] = 'You must have at least 1 recipient.'; // 
//2do
$app_strings['LBL_MESSAGE_SENT_CLICK_RELOAD'] = 'Message sent. Click RELOAD button to refresh your window.'; // 

// modules/Administration/transfer.php
$app_strings['LBL_TRANSFER'] = 'Transfer of existing contacts'; // 

$app_strings['LBL_FOUND'] = 'Found <strong>'; // 
$app_strings['LBL_CONTACTS'] = '</strong> contacts.<br>'; //
$app_strings['LBL_LIMITATIONS_IMPORT'] = 'Limitations for number of contacts per one import operation <strong> '; // 
$app_strings['LBL_LIMITATIONS_IMPORT2'] = 'contacts >'; // 
$app_strings['LBL_LIMITATIONS_IMPORT3'] = ', import will be using parts not more then '; // 
$app_strings['LBL_LIMITATIONS_IMPORT4'] = ' per operation.<br>'; // 
$app_strings['LBL_TRANSFERED'] = 'Transferred to Unisender - <strong>'; // 
$app_strings['LBL_TRANSFERED2'] = '</strong> contacts.<br>'; // 


// custom/unisender/inc/header.all.php
$app_strings['LBL_UNISENDER_INC_ALT'] = 'Web-based email newsletters and bulk sms';
$app_strings['LBL_UNISENDER_INC_OPEN_ACCOUNT'] = 'Open account in UniSender';
$app_strings['LBL_UNISENDER_INC_REPLENISH_ACCOUNT'] = 'Replenish account in UniSender';
$app_strings['LBL_UNISENDER_INC_INFO_ADD'] = '1. New contacts (name, e-mail, phone) will be added to UniSender list that can be changed ';
$app_strings['LBL_UNISENDER_INC_INFO_IN_SETTINGS'] = 'via settings';
$app_strings['LBL_UNISENDER_INC_INFO_SEND'] = '2. To send sms from contact details or via Actions here choose';
$app_strings['LBL_UNISENDER_INC_INFO_MODULE'] = 'module';
$app_strings['LBL_UNISENDER_INC_INFO_AND_ASSIGN'] = ' and assing ';
$app_strings['LBL_UNISENDER_INC_INFO_FIELDS'] = 'fields';
$app_strings['LBL_UNISENDER_INC_INFO_FOR_SMS'] = ' for SMS.';
// custom/unisender/unisender.php
$app_strings['LBL_UNISENDER_API_ACCESS_ERROR'] = 'API access error'; //API access error
$app_strings['LBL_UNISENDER_INVALID_JSON'] = 'Invalid JSON'; //Invalid JSON
$app_strings['LBL_UNISENDER_ERROR_OCCURED'] = 'An error occured:'; //An error occured:
//
$app_strings['LBL_UNISENDER_ERROR_MSG'] = 'Error message: '; //
$app_strings['LBL_UNISENDER_ERROR_CODE'] = 'Error code: '; //
// authenticate()
// getBalance()
//
// getLists()
// getListsSelect()
// isexistList()
// createList()
//
// importContacts()
// subscribe()
//
// sendSms()
// error
$app_strings['LBL_UNISENDER_ERROR_OCCURED_SMS'] = 'An error occured during SMS send sessions: '; //
// sent
$app_strings['LBL_UNISENDER_SMS_SENT'] = 'SMS message sent:'; //
$app_strings['LBL_UNISENDER_SMS_ID'] = 'Message id: '; //
$app_strings['LBL_UNISENDER_SMS_COST'] = 'SMS message cost '; //


