<?php

$app_list_strings['moduleList']['unisender_SMS'] = 'SMS';
$app_list_strings['type_list']['inbound'] = 'Входящее'; // inbound
$app_list_strings['type_list']['outbound'] = 'Исходящее'; // outbound

$app_list_strings['delivery_status_list']['SENT'] = 'Отправлено';
$app_list_strings['delivery_status_list']['FAILED'] = 'Не доставлено';
$app_list_strings['delivery_status_list']['ERROR'] = 'Ошибка';
$app_list_strings['delivery_status_list']['RECEIVED'] = 'Получено'; //future

$app_list_strings['campaign_type_dom'][''] = ''; 
$app_list_strings['campaign_type_dom']['Email'] = 'Рассылка E-mail'; 
$app_list_strings['campaign_type_dom']['Mail'] = 'Почтовая рассылка'; 
$app_list_strings['campaign_type_dom']['NewsLetter'] = 'Информ. бюллетень'; 
$app_list_strings['campaign_type_dom']['Print'] = 'Печать'; 
$app_list_strings['campaign_type_dom']['Radio'] = 'Радио';
//nonupgradesafe2
$app_list_strings['campaign_type_dom']['SMS'] = 'UniSender SMS'; 
//
$app_list_strings['campaign_type_dom']['Telesales'] = 'Продажи по телефону'; 
$app_list_strings['campaign_type_dom']['Television'] = 'Телевидение'; 
$app_list_strings['campaign_type_dom']['Web'] = 'Веб-реклама';  
 
/////////////////////////////////////////////////////////////////////////////////////////////

// custom/fieldFormat/sms_phone_fields.php
$app_strings['LBL_CLICK_TO_SEND_SMS'] = 'Нажмите на телефон для СМС сообщения. Подождите пока откроется всплывающее окно.'; //Click to send an SMS. Opening the editor may take a moment. Please give it some time.

// nonupgradesafe/include/ListView/6.2.4/ListViewDisplay.php
$app_strings['LBL_LISTVIEW_COMPOSE_SMS_UNISENDER'] = 'SMS через UniSender'; // UniSender SMS

// modules/Administration/smsProvider.php
$app_strings['LBL_PRESS_ESC_OR_CLICK_GRAY_AREA'] = 'Нажмите ESC или кликните на серой области.'; // Press ESC key or click the gray area to close this message.
$app_strings['LBL_SAVE'] = 'Сохранить'; // Save

// modules/Administration/customUsage.php
$app_strings['LBL_CLICK_REPAIR_TO_APPLY'] = 'Нажмите Восстановить, чтобы применить настройки.'; // Click Repair button to apply your customization
$app_strings['LBL_SMS_MODULES_RELATIONSHIP'] = 'Взаимосвязи СМС и модулей'; // SMS & Module Relationships
$app_strings['LBL_MOVE_MODULE_RIGHT'] = 'Переместите модуль вправо, чтобы установить взаимосвязи'; // Move a module to the right panel to create a relationship with SMS
$app_strings['LBL_CLICK_SELECT_DESELECT'] = 'Нажмите, чтобы выбрать/отменить'; // Click to select or deselect 

// modules/Administration/unisender_customUsage/javascript/customUsage.js
//$app_strings['LBL_CLICK_SELECT_DESELECT']

// modules/Administration/unisender_smsPhone/sms_editor.php
$app_strings['LBL_RECIPIENTS'] = 'Получатели'; // Recipients 
$app_strings['LBL_CLICK_TO_REMOVE'] = 'Нажмите, чтобы удалить'; // Click to remove
$app_strings['LBL_YOU_REMOVED_ALL_RECIPIENTS'] = 'Вы удалили всех получателей. <br>Нажмите ESC или кликните на серой области.'; // You removed all recipients. <br>Press ESC key or click the gray area to close this message.
$app_strings['LBL_PHONE_NUMBER'] = 'Номер телефона'; // Phone Number
$app_strings['LBL_COUNTRY_CODE'] = 'код страны'; // country code
$app_strings['LBL_NUMBER'] = 'номер'; // number
$app_strings['LBL_TEMPLATE'] = 'Шаблон'; // Template
$app_strings['LBL_MESSAGE'] = 'Сообщение '; // Message 
$app_strings['LBL_LIMIT_YOUR_MESSAGE'] = 'Ограничьтесь 140 символами'; // Limit your message up to 140 characters only.
$app_strings['LBL_PRESS_ESC_TO_CLOSE'] = 'Нажмите ESC, чтобы закрыть'; // Press ESC key to close.
$app_strings['LBL_SEND'] = 'Отправить'; // Send

// modules/Administration/smsPhone.php
$app_strings['LBL_SELECT_FIELDS_LOADED'] = 'Выбранные поля добавлены для согласования.'; // Selected fields were successfully loaded for customization.
//$app_strings['LBL_SELECT_FIELDS_LOADED'] = 'To effect the changes, click <Strong>Repair</strong> button.';
 // To effect the changes, click <Strong>Repair</strong> button.
$app_strings['LBL_FIELD_SELECTOR'] = 'Выбор полей для СМС'; // Field Selector
$app_strings['LBL_SELECT_RELATED_MODULE'] = 'Выберите модуль'; // Select a related module
$app_strings['LBL_NEED_TO_SET_RELATIONSHIPS_BETWEEN_SMS'] = 'Требуется установить взаимосвязи между модулями. '; // You may need to set a relationship between the SMS module and the other modules.
$app_strings['LBL_CLICK'] = 'Нажмите '; // Click
$app_strings['LBL_HERE'] = 'здесь'; // here
$app_strings['LBL_TO_SET_RELATIONSHIP'] = ' , чтобы установить взаимосвязи.</p>'; //  to set the relationship.</p>
$app_strings['LBL_TO_CONFIGURE_FIELD_AS_SMS'] = 'Переместите поле для СМС вправо'; // To configure a field as an sms number, move the field to the right panel
$app_strings['LBL_SELECT_RELATED_MODULE'] = 'Укажите модуль.'; // Please select a related module.
$app_strings['LBL_REPAIR'] = 'Восстановить'; // Repair

// modules/Administration/unisender_smsPhone/javascript/smsPhone.js
$app_strings['LBL_TIP'] = '<p>Укажите полный номер без пробелов и разделителей<div align=center>&lt; КОД СТРАНЫ &gt;&lt; НОМЕР ТЕЛЕФОНА &gt;</div></p><p>Пример:</p><table><tr><td>Россия (+7) </td><td>&nbsp;&nbsp;<strong>903 1234567</strong></td></tr></strong></td></tr></table>';
//<p>Please key in the full number without any separator in the following format" +
//		        "<div align='center'>&lt; COUNTRY CODE &gt;&lt; PHONE NUMBER &gt;</div></p>" +
///		        "<p>Example:</p><table><tr><td>Russia (+7) </td><td>&nbsp;&nbsp;<strong>903 1234567</strong></td></tr></table>"

$app_strings['LBL_SENDING'] = 'Отсылаем...'; // Sending... Please wait!
//2do
$app_strings['LBL_CLICL_OK_TO_CLEAR_CUSTOMIZATION'] = 'Нажмите OK для сброса настроек '; // Click OK to clear phone field customization for 
//2do
$app_strings['LBL_YOU_NEED_TO_SELECT_FIELD'] = 'Выберите поле и введие SMS macro.'; // You need to select a field and enter an SMS macro string.
//2do
$app_strings['LBL_LOADING'] = 'Загружаем...'; // Loading...
//2do
$app_strings['LBL_140_CHARS'] = '/140 символов.'; // /140 characters. 
//2do
$app_strings['LBL_YOU_MUST_HAVE_1_RECIPIENT'] = 'Нужен как минимум 1 получатель.'; // You must have at least 1 recipient.
//2do
$app_strings['LBL_MESSAGE_SENT_CLICK_RELOAD'] = 'Сообщение отправлено. Нажмите RELOAD для обновления.'; // Message sent. Click RELOAD button to refresh your window.

// modules/Administration/transfer.php
$app_strings['LBL_TRANSFER'] = 'Перенос существующих контактов'; // Transfer of existing contacts

$app_strings['LBL_FOUND'] = 'Найдено <strong>'; // Found
$app_strings['LBL_CONTACTS'] = '</strong> контактов.<br>'; // contacts
$app_strings['LBL_LIMITATIONS_IMPORT'] = 'Ограничение на количество контактов за одну операцию импорта <strong> '; // 
$app_strings['LBL_LIMITATIONS_IMPORT2'] = 'Контактов >'; // 
$app_strings['LBL_LIMITATIONS_IMPORT3'] = ', импорт будет по частям не больше '; // 
$app_strings['LBL_LIMITATIONS_IMPORT4'] = ' за раз.<br>'; // 
$app_strings['LBL_TRANSFERED'] = 'Передано в Unisender - <strong>'; // 
$app_strings['LBL_TRANSFERED2'] = '</strong> контактов.<br>'; // 


// custom/unisender/inc/header.all.php
$app_strings['LBL_UNISENDER_INC_ALT'] = 'Правильный e-mail маркетинг и рассылка';
$app_strings['LBL_UNISENDER_INC_OPEN_ACCOUNT'] = 'Открыть аккаунт UniSender';
$app_strings['LBL_UNISENDER_INC_REPLENISH_ACCOUNT'] = 'Пополнить счёт в UniSender';
$app_strings['LBL_UNISENDER_INC_INFO_ADD'] = '1. Новые контакты (имя, e-mail, телефон) будут добавляться в UniSender-список, который можно поменять';
$app_strings['LBL_UNISENDER_INC_INFO_IN_SETTINGS'] = 'в настройках';
$app_strings['LBL_UNISENDER_INC_INFO_SEND'] = '2. Чтобы отправлять смс из карточки контакта или через Действия, выберите';
$app_strings['LBL_UNISENDER_INC_INFO_MODULE'] = 'модуль';
$app_strings['LBL_UNISENDER_INC_INFO_AND_ASSIGN'] = ' и назначьте ';
$app_strings['LBL_UNISENDER_INC_INFO_FIELDS'] = 'поля';
$app_strings['LBL_UNISENDER_INC_INFO_FOR_SMS'] = ' для смс.';
// custom/unisender/unisender.php
$app_strings['LBL_UNISENDER_API_ACCESS_ERROR'] = 'Ошибка соединения с API-сервером'; //API access error
$app_strings['LBL_UNISENDER_INVALID_JSON'] = 'Ошибка в полученном ответе от API-сервера'; //Invalid JSON
$app_strings['LBL_UNISENDER_ERROR_OCCURED'] = 'Произошла ошибка:'; //An error occured: 
//
$app_strings['LBL_UNISENDER_ERROR_MSG'] = 'Сообщение об ошибке: '; //
$app_strings['LBL_UNISENDER_ERROR_CODE'] = 'Код ошибки: '; //
// authenticate()
// getBalance()
//
// getLists()
// getListsSelect()
// isexistList()
// createList()
//
// importContacts()
// subscribe()
//
// sendSms()
// error
$app_strings['LBL_UNISENDER_ERROR_OCCURED_SMS'] = 'Ошибка отправки СМС-сообщения:'; //
// sent
$app_strings['LBL_UNISENDER_SMS_SENT'] = 'СМС сообщение отправлено:'; //
$app_strings['LBL_UNISENDER_SMS_ID'] = 'Идентификатор сообщения '; // - 1
$app_strings['LBL_UNISENDER_SMS_COST'] = 'Стоимость СМС сообщения '; // - 2

