<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('modules/Contacts/ContactFormBase.php');
$contactForm = new ContactFormBase();
$prefix = empty($_REQUEST['dup_checked']) ? '' : 'Contacts';
$contactForm->handleSave($prefix, true, false);

// Unisender-Suite-1.0
//global $log;

global $sugar_config;
$api_key = $sugar_config['unisender_api_key'];
include_once("custom/unisender/unisender.php");
$api = new unisender($api_key);

//$balance = $api->getBalance();
//$log->fatal("@ modules/Contacts/Save.php " . __CLASS__ . ":" . __LINE__ . " api-getBalance $balance");

// 1
include_once("modules/Contacts/Contact.php");
$contact = new Contact();
if(isset($_POST['record']) && !empty($_POST['record'])) {
	$contact->retrieve($_POST['record']);
}
$return_id = $contact->id;

// 2
$contact_4_api = array();
$contact_4_api['name'] = $contact->first_name; // CONCAT(c.first_name, \" \", c.last_name)
$contact_4_api['phone'] = $contact->phone_mobile;
$contact_4_api['email'] = $contact->contact_email = $contact->emailAddress->getPrimaryAddress($contact);

$person = $api->subscribe($contact_4_api);
//$log->fatal("@ modules/Contacts/Save.php " . __CLASS__ . ":" . __LINE__ . " person $person");

// /Unisender-Suite-1.0

?>