<?php 
			
// items
$admin_option_defs = array();

// Configurator

// 1
$admin_option_defs['Administration']['config1'] = array(
	'Password', //'icon_AdminMobile',
	'LBL_UNISENDER_CONFIG', //'Gateway Settings',
	'LBL_UNISENDER_CONFIG_DESC', // "Configure provider's gateway details",
	'./index.php?module=Configurator&action=unisender_config'
); 

// 2
$admin_option_defs['Administration']['config2'] = array(
	'ProjectExpandAll', // icon_email_options
	'LBL_UNISENDER_CONFIG2',
	'LBL_UNISENDER_CONFIG2_DESC',
	'./index.php?module=Configurator&action=unisender_config2'
); 

// Administration

// 2
$admin_option_defs['Administration']['config3']= array(
	'icon_AdminMobile',
	'LBL_UNISENDER_MODULES', //'SMS & Modules Relationship',
	'LBL_UNISENDER_MODULES_DESC', //'Customize the related modules for SMS module',
	'./index.php?module=Administration&action=customUsage'
);

// 3	
$admin_option_defs['Administration']['config4'] = array(
	'icon_AdminMobile',
	'LBL_UNISENDER_FIELDS', //'Field selector',
	'LBL_UNISENDER_FIELDS_DESC', //'Select phone numbers that are SMS capable',
	'./index.php?module=Administration&action=smsPhone'
);  
		
// 4
$admin_option_defs['Administration']['config5']= array(
	'OpportunityReports',
	'LBL_UNISENDER_BALANCE', //'SMS Credit Balance',
	'LBL_UNISENDER_BALANCE_DESC', //"Check your account's available credits",
	'./index.php?module=Administration&action=smsProvider&option=smsBalance'
);		

// 5
/*
$admin_option_defs['Administration']['config5']= array(
	'icon_AdminMobile',
	'LBL_UNISENDER_MACRO', //'SMS Macro',
	'LBL_UNISENDER_MACRO_DESC', //'Sets SMS macro for every module',
	'./index.php?module=Administration&action=smsProvider&option=macro'
);
*/

// 6
$admin_option_defs['Administration']['config6']= array(
	'ProjectIndent', // icon_email_forward
	'LBL_UNISENDER_TRANSFER',
	'LBL_UNISENDER_TRANSFER_DESC',
	'./index.php?module=Administration&action=transfer'
);


// group				
$admin_group_header[]= array(
	'LBL_UNISENDER',
	'icon_unisender_mascot', // icon_unisender_mascot
	false,
	$admin_option_defs, 
	'LBL_UNISENDER_DESC'
);
