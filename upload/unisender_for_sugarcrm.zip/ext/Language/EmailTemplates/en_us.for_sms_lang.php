<?php
$mod_strings['LBL_SMS_ONLY'] = 'Unisender SMS Only';
?>
