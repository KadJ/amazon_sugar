<?php
$mod_strings['LBL_SMS_ONLY'] = 'Только Unisender SMS';
?>
