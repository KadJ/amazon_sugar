<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

if(!is_admin($current_user)) sugar_die('Admin Only');

global $sugar_config;
global $mod_strings, $app_strings, $app_list_strings;
//require_once 'custom/include/Krumo/class.krumo.php';

// check - 1 before N
$api_key = $sugar_config['unisender_api_key'];
if (empty($api_key)) {
	SugarApplication::redirect('index.php?module=Configurator&action=unisender_config');
}

require_once('modules/Configurator/Forms.php');
require_once('modules/Configurator/Configurator.php');

// Page header
//echo get_module_title($mod_strings['LBL_MODULE_ID'], $mod_strings['LBL_SUGARDEV_CONF_TITLE'], true);
echo get_module_title($mod_strings['LBL_MODULE_ID'], $mod_strings['LBL_UNISENDER_CONFIG'] . ":", true);

// Defaults
$unisender_config['unisender_list_transfer'] 	= ''; // for transferring existing contacts to Unisender (manual)
$unisender_config['unisender_list_add'] 	 	= ''; // for adding new contacts to Unisender (automatic)
$unisender_config['unisender_sender'] 	 		= ''; // SNsalon instead of +79207712702/79207712702

//add config vars to sugar config. need by Configurator class
global $sugar_config;
foreach ($unisender_config as $key => $value) {
	if (!isset($sugar_config[$key])) {
		$sugar_config[$key] = '';
	}
}

$configurator = new Configurator();
$focus = new Administration();

if(!empty($_POST['save'])){
	//set defaults for saving
	foreach ($unisender_config as $key => $value) {
		if (isset($_REQUEST[$key]) && $_REQUEST[$key] == '') {	
			$_REQUEST[$key] = $value; 
		}
	}
	$configurator->saveConfig();	
	$focus->saveConfig();
	//header('Location: index.php?module=Administration&action=index');
	SugarApplication::redirect('index.php?module=Administration');
}

$focus->retrieveSettings();
if(!empty($_POST['restore'])){
	$configurator->restoreConfig();	
}

require_once('include/Sugar_Smarty.php');
$sugar_smarty = new Sugar_Smarty();

$sugar_smarty->assign('MOD', $mod_strings);
$sugar_smarty->assign('APP', $app_strings);
$sugar_smarty->assign('APP_LIST', $app_list_strings);

$sugar_smarty->assign('config', $configurator->config);
$sugar_smarty->assign('unisender_config', $unisender_config);

//
$sugar_smarty->assign('unisender_list_transfer_options', get_unisender_lists('unisender_list_transfer'));
$sugar_smarty->assign('unisender_list_add_options', get_unisender_lists('unisender_list_add'));

$sugar_smarty->assign('error', $configurator->errors);

$sugar_smarty->display('modules/Configurator/tpls/unisender_config2.tpl');

require_once("include/javascript/javascript.php");
$javascript = new javascript();
$javascript->setFormName("ConfigureUnisenderSettings2");

$javascript->addFieldGeneric("unisender_list_transfer", "varchar", $mod_strings['LBL_UNISENDER_LIST_TRANSFER'], TRUE, "");
$javascript->addFieldGeneric("unisender_list_add", "varchar", $mod_strings['LBL_UNISENDER_LIST_ADD'], TRUE, "");
$javascript->addFieldGeneric("unisender_sender", "alphanumeric", $mod_strings['LBL_UNISENDER_CONFIG_SENDER'], TRUE, "");

echo $javascript->getScript();

//
function get_unisender_lists ($var) {
	global $sugar_config;
	$api_key = $sugar_config['unisender_api_key'];
	//
	include_once("custom/unisender/unisender.php");
	$api = new unisender($api_key);
	//
	$lists = $api->getListsSelect(); // for Sugar DropDown
	//
	$options = getSelectOptions($lists,$var);
	$res = '<select name="' . $var . '">' . $options . '</select>';
	return $res;
}
//
function getSelectOptions($list,$selected) {
    $options = '';
    global $sugar_config;
    foreach ($list as $item => $description) {
    	$selected_html='';
    	if ($item==$sugar_config[$selected]) { $selected_html='SELECTED'; }
     	$options .= '<option value="'. $item . '" '.$selected_html.'>'. $description . '</option>';
    }
    return $options;
}

