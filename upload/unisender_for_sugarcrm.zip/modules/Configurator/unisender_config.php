<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

if(!is_admin($current_user)){
	sugar_die('Admin Only');	
}

require_once('modules/Configurator/Forms.php');
require_once('modules/Configurator/Configurator.php');

// Page header
//echo get_module_title($mod_strings['LBL_MODULE_ID'], $mod_strings['LBL_SUGARDEV_CONF_TITLE'], true);
echo get_module_title($mod_strings['LBL_MODULE_ID'], $mod_strings['LBL_UNISENDER_CONFIG'] . ":", true);

// Defaults
$unisender_config['unisender_api_key'] 	 = '';
//$unisender_config['unisender_api_key'] 	 = '5s9fbs3n4enkqjy3ziswcws9ofqypyes6x9ei4uy'; // snsalon
// $sugar_config['host_name'] = 'sebastian-nikol.ru'
// $sugar_config['site_url'] = 'http://sebastian-nikol.ru/crm'
$unisender_config['unisender_domain_name'] 	 	= $sugar_config['host_name']; // for additional check

//add config vars to sugar config. need by Configurator class
global $sugar_config;
foreach ($unisender_config as $key => $value) {
	if (!isset($sugar_config[$key])) {
		$sugar_config[$key] = '';
	}
}

$configurator = new Configurator();
$focus = new Administration();

if(!empty($_POST['save'])){
	//set defaults for saving
	foreach ($unisender_config as $key => $value) {
		if (isset($_REQUEST[$key]) && $_REQUEST[$key] == '') {	
			$_REQUEST[$key] = $value; 
		}
	}
	$configurator->saveConfig();	
	$focus->saveConfig();
	//header('Location: index.php?module=Administration&action=index');
	SugarApplication::redirect('index.php?module=Administration');
}

$focus->retrieveSettings();
if(!empty($_POST['restore'])){
	$configurator->restoreConfig();	
}

require_once('include/Sugar_Smarty.php');
$sugar_smarty = new Sugar_Smarty();

$sugar_smarty->assign('MOD', $mod_strings);
$sugar_smarty->assign('APP', $app_strings);
$sugar_smarty->assign('APP_LIST', $app_list_strings);

$sugar_smarty->assign('config', $configurator->config);
$sugar_smarty->assign('unisender_config', $unisender_config);

$sugar_smarty->assign('error', $configurator->errors);

$sugar_smarty->display('modules/Configurator/tpls/unisender_config.tpl');

require_once("include/javascript/javascript.php");
$javascript = new javascript();
$javascript->setFormName("ConfigureUnisenderSettings");

/* Unisender Suite - API */
$javascript->addFieldGeneric("unisender_api_key", "varchar", $mod_strings['LBL_UNISENDER_CONFIG_API_KEY'], TRUE, "");
echo $javascript->getScript();

