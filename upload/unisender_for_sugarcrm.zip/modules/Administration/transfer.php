<?php 
if(!defined('sugarEntry')) define('sugarEntry', true);

if(!is_admin($current_user)){
  sugar_die('Admin Only');  
}

global $sugar_config;
global $mod_strings;
//require_once 'custom/include/Krumo/class.krumo.php';

// check - 1(api) before N
$api_key = $sugar_config['unisender_api_key'];
if (empty($api_key)) {
  SugarApplication::redirect('index.php?module=Configurator&action=unisender_config');
}

// check - 2(lists) before 6(transfer)
$list_transfer = $sugar_config['unisender_list_transfer'];
if (empty($list_transfer)) {
  SugarApplication::redirect('index.php?module=Configurator&action=unisender_config2');
}

echo "<div class='moduleTitle'><h2><a href='index.php?module=Administration&action=index'>UniSender</a><span class='pointer'>&raquo;</span>" .$app_strings['LBL_TRANSFER']. "</h2></div>";

//global $db;
require_once("include/database/DBManager.php");
$db = & DBManagerFactory::getInstance();

//$sql = "SELECT c.id as id, CONCAT(c.first_name, \" \", c.last_name) as name, phone_mobile, email_address FROM contacts c";
$sql = "SELECT contacts.id as id, ";
$sql .= "contacts.first_name as name, ";
//$sql .= db_concat(contacts,array('first_name','last_name')) . " name, ";
$sql .= "contacts.phone_mobile as phone ";
//$sql .= "LEFT JOIN email_addr_bean_rel eabl ON eabl.bean_id = contacts.id AND eabl.bean_module = 'Contacts' and eabl.primary_address = 1 and eabl.deleted=0 ";
//$sql .= "LEFT JOIN email_addresses ea ON (ea.id = eabl.email_address_id) ";
$sql .= "FROM contacts";

$result = $db->query($sql, true, "Error retrieving contacts : ");

$contacts = array();
while ($row = $db->fetchByAssoc($result)) {
	//Krumo($row);

	$co_id = $row['id'];

	require_once("modules/Contacts/Contact.php");
	$contact = new Contact();
    $contact->retrieve($co_id);

    if($contact->id != "") {
       $row['email'] = $contact->contact_email = $contact->emailAddress->getPrimaryAddress($contact) ;
    }

	$contacts[] = $row;

} /* /while */

//krumo($contacts);

$api_key = $sugar_config['unisender_api_key'];
include_once("custom/unisender/unisender.php");
$api = new unisender($api_key);

$import_limiter = 500; // Sugar/UniSender limitations
//
$no_contacts = count($contacts);
echo $app_strings['LBL_FOUND'] .$no_contacts .$app_strings['LBL_CONTACTS'].;

if ($no_contacts>$import_limiter) {
  echo $app_strings['LBL_LIMITATIONS_IMPORT'] .$import_limiter . '</strong>.<br><br>';
  echo $app_strings['LBL_LIMITATIONS_IMPORT2'] .$import_limiter .$app_strings['LBL_LIMITATIONS_IMPORT3'] . $import_limiter .$app_strings['LBL_LIMITATIONS_IMPORT4'];
}

$cycles = floor($no_contacts / $import_limiter);
$contacts_cycled = $cycles*$import_limiter;
$contacts_left = $no_contacts - $contacts_cycled;

/*
if ($cycles>0) {
  echo 'Будет ' . $cycles . ' частей по ' . $import_limiter . ' контактов. ';
  if ($contacts_left>0) {
    echo 'И последний шаг из ' . $contacts_left . ' контактов.';
  }
}
*/

//echo 'cycles='.$cycles.', contacts_cycled='.$contacts_cycled.', contacts_left='.$contacts_left.'<br>';

require_once('include/utils/progress_bar_utils.php');
display_flow_bar('myflow', 1);
display_progress_bar('total',0,$no_contacts);

// cycles
$slice = 0;
while ($cycles>0) {
  //echo 'cycle';

  $contacts_sliced = array_slice($contacts, $slice, $import_limiter);
  //
  $no = $api->importContacts($contacts_sliced);
  echo $app_strings['LBL_TRANSFERED'] .$no .$app_strings['LBL_TRANSFERED2'];
  //
  $slice += $import_limiter;
  update_progress_bar('total',$slice, $no_contacts);
  //sleep(1);
  //
  --$cycles;
}

//echo 'cycles='.$cycles.', contacts_cycled='.$contacts_cycled.', contacts_left='.$contacts_left.'<br>';

// left
//$slice = 0; if ($cycles>0) { $slice = $contacts_cycled-1; }
//echo 'left_slice='.$slice;

//krumo($slice);
if ($contacts_left>0) {
  $contacts_sliced = array_slice($contacts, $slice, $contacts_left); // starting from 0
  //
  $no = $api->importContacts($contacts_sliced);
  echo $app_strings['LBL_TRANSFERED'] .$no .$app_strings['LBL_TRANSFERED2'];
  //
  $slice += $contacts_left;
  update_progress_bar('total',$slice, $no_contacts);
}

destroy_flow_bar('myflow');
