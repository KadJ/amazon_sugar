<?php 
if(!defined('sugarEntry')) define('sugarEntry', true);

include_once('modules/Configurator/Configurator.php'); 
include_once('sugar_version.php');

require_once('custom/sms/sms.php'); 

global $sugar_config;
global $mod_strings;

define("MSG_ERROR", $mod_strings['LBL_ERROR'] );

//require_once 'custom/include/Krumo/class.krumo.php';

if(!defined("MSG_UNVERIFIED")) 
	define("MSG_UNVERIFIED", $mod_strings['LBL_UNABLE_TO_AUTHENTICATE'] );

$sms = new sms();
//$parent_link = "<a href='index.php?module=Administration&action=index'>Administration</a><span class='pointer'>&raquo;</span>";
$parent_link = "<a href='index.php?module=Administration&action=index'>UniSender</a><span class='pointer'>&raquo;</span>";
 
if (isset($_GET['option'])) {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
 	 
	switch($_GET['option']) {
	
		/* 4 -  */
		case "smsBalance":
			
			// check - 1 before N
			$api_key = $sugar_config['unisender_api_key'];
			if (empty($api_key)) {
				SugarApplication::redirect('index.php?module=Configurator&action=unisender_config');
			}

			//$sms->retrieve_settings();
			//if (empty($sms->params['sms_instance_id'])) {
			if ( $sms->not_ready ) {
				echo "<div style='background-color:#fff;padding:10px;text-align:center;'>".$mod_strings['LBL_NOT_SPECIFIED_API_KEY'];
				echo " ".$mod_strings['LBL_CLICK']." <a href='./index.php?module=Administration&action=smsProvider'>".$mod_strings['LBL_HERE']."</a> ".$mod_strings['LBL_TO_SETUP_YOUR_ACCOUNT']."</div>";
				break;
			}

			$res = $sms->authenticate($sms->params['sms_instance_id']); //Krumo($res);
			
			echo "<div class='moduleTitle'><h2>{$parent_link}".$mod_strings['LBL_SMS_BALANCE']."</h2></div>";
			echo "<table class='edit view small' width='100%' border='0' cellspacing='1' cellpadding='0' ><tr><td>";
			echo "<div style='text-align:center;'>"; // font-size:14px;padding:50px;'>";
			
			if ( (string)$res == MSG_ERROR) {
				echo MSG_UNVERIFIED;
			} else {
				$res = (empty($res) or $res==0) ? "0.00" : $res;
				echo $mod_strings['LBL_SMS_BALANCE2'] .$res .'</strong>.<br>'; // {$res}
				echo $mod_strings['LBL_SMS_BALANCE3'];
			}
			
			echo "</div>";
			echo '</td></tr></table>';
			break;
			
	/* - */
		case "create_sms_config":
			//$my_api_key = $_POST['sms_instance_id'];
			$api_key = $sugar_config['unisender_api_key'];
			if (empty($api_key)) {
				SugarApplication::redirect('index.php?module=Configurator&action=unisender_config');
			}
			$sms->params['sms_instance_id'] = $api_key;
			//
			$sms->params['sender'] = 'Unisender';
			$sms->save_settings();
			//
			break;
	
		/* + */
		case "load_mod_fields": 
			if (isset($_GET["m"])) { 
				if ($_GET["m"] == '') {
					echo "<em>-Please select a module-</em>";
				} else {
					require_once("modules/Administration/unisender_smsPhone/sms_enzyme.php");
					$e = new sms_enzyme($_GET["m"]);
					echo $e->load_module_fields('macro_field','select');
				}  
			}
			break; 
	
		/* 6 + */
		/*
		case "macro":
			//include iz/sms_macro.inc.php
		*/
		/* /macro */
		
		/* + */
		case "save":
			if (isset($_POST)) { 
				foreach($_POST as $fld => $val) {   
					$sms->params[$fld] = $val;
				} 
				$sms->save_settings(); 
                echo "<span style='color:#000'>Successfully saved your settings.</span>";
			} else {
				echo "The data you were trying to save is empty.";
			} 
			break;
			
		/* + */
		case "test_conn": 
			if (!empty($_POST['account_id'])) {  
				//
				$res = $sms->authenticate($_POST['account_id']); 
				if ($res == 'ERROR') {
					echo "<div>".MSG_UNVERIFIED."<div>";
				} else {
					echo "<div>Account verified.</div>";
					if ($res == "POSTPAID") {
						echo "<div>You are allowed to send unlimited number of text messages.</div>";
					} else {
						$res = (empty($res) or $res==0) ? "0.00" : $res;
						echo "<div>You have <strong>{$res}</strong> sms credits on your account.</div>";
					}
				}  
			} else {
				echo "The data you were trying to save is empty.";
			} 
			break;
			
		/* - called from smsPhone.js */
		case "send":   
		
			//$sms->retrieve_settings();  
			
			// 1.0 - authenticated
			if (empty($sms->params['sms_instance_id'])) {
				echo "<div style='background-color:#fff;padding:10px;text-align:center;'>You have not specified an SMS gateway for this purpose. ";
                echo "Click <a href='./index.php?module=Administration&action=smsProvider'>here</a> to setup your gateway account.</div>";
				break;
			} 
			
			//if ($sms->authenticate($sms->params['sms_instance_id']) == 'ERROR') {
			$res = $sms->authenticate(); //Krumo($res);
			if ( (string)$res == MSG_ERROR) {
				echo MSG_UNVERIFIED;
				break;
			}
			
			if(isset($_POST) && !empty($_POST)) {  
				
				if ($_POST["send_to_multi"]) { 

					#multiple recipient 
					$sms->params = $sms->params;  
					$sms->parent_type = $_POST['ptype']; 
					 
					$mod_key_sing = $GLOBALS["beanList"][$_POST['ptype']];
					$object_name = $mod_key_sing=='aCase' ? 'Case' : $mod_key_sing;
					$mod_bean_files = $GLOBALS["beanFiles"][$mod_key_sing];  
 					
					# retrieve configured SMS phone field for the active module
					require_once("modules/Administration/unisender_smsPhone/sms_enzyme.php");
					$e = new sms_enzyme($_POST['ptype']);
					$sms_field = $e->get_custom_phone_field(); 
 				 	
					$summary = array();
					$pids = explode(",", $_POST['pid']); 
					if (sizeof($pids) && $sms_field!=NULL) {
						require_once($mod_bean_files);
						$number = array();
						$recipient = array();
						foreach($pids as $pid) { 
							$parent = new $object_name;
							if($parent->retrieve($pid)) {
								$fone = preg_replace('/[^0-9]/', '', $parent->$sms_field);  
								$number[$pid] = array($parent->name, $fone); 
								$recipient[$pid]['name'] = $parent->name;  
							}  
						}  
						if(!empty($number)){ 
							$summary = $sms->send_batch_message($number, $_POST["sms_msg"]);
						}
						//echo "SUMMARY:<br>";
						 
						if (is_array($summary)) { 
							echo "<table width='100%' border='0' cellpadding='2'>"; 
							foreach ($summary as $pid => $val) {
								echo "<tr><td valign='top'>" . $recipient[$pid]['name'] . "</td>";
								echo "<td valign='top'>{$val['api_message']}</td></tr>";
							} 
							echo "</table>";
						} else {
							echo $summary;
						}
						echo "<div style='margin-top:15px;'>" .$app_strings['LBL_PRESS_ESC_OR_CLICK_GRAY_AREA'].  "</div>";
					}  
					
				}  else { 

					# single recipient
					$sms->parent_type = $_POST['ptype'];
					$sms->parent_id = $_POST['pid'];
					$sms->pname = $_POST["pname"];  
					echo $sms->send_message($_POST["num"], $_POST["sms_msg"]);
				}   
			 
			} else {
				echo "Message sending failed. The data you submitted is empty.";
			}  
			break; 
		
		/* - */
		case "resend":
 			$sms->retrieve_settings(); 
			if ($sms->authenticate($sms->params['sms_instance_id']) == 'ERROR') {
				echo MSG_UNVERIFIED;
				break;
			}
			if (empty($sms->params['sms_instance_id'])) {
				echo "<div style='background-color:#fff;padding:10px;text-align:center;'>You have not specified an SMS gateway for this purpose. ";
                                echo "Click <a href='./index.php?module=Administration&action=smsProvider'>here</a> to setup your gateway account.</div>";
				break;
			}
			if (isset($_POST) and !empty($_POST['rec']) and !empty($_POST['num'])) {   
				echo $sms->resend($_POST['rec'], $_POST['num'], $_POST['sms_msg']);
			} 
			break;
			
		/**/
		case "editor":
		
		 	$sms->retrieve_settings();

			if (empty($sms->params['sms_instance_id'])) {
				echo "<div style='background-color:#fff;padding:10px;text-align:center;'>You have not specified an SMS gateway for this purpose. ";
                                echo "Click <a href='./index.php?module=Administration&action=smsProvider'>here</a> to setup your gateway account.</div>";
				break;
			}

			if (isset($_GET['rec'])) {
			
				$unisender_SMS = new unisender_SMS();
				$unisender_SMS->retrieve($_GET['rec']);
				$phone_number = $unisender_SMS->phone_number;
				$msg = $unisender_SMS->description;
				$pid = $unisender_SMS->id;	// uses $pid to store the record id 
				$ptype = $unisender_SMS->parent_type; // not really needed but may be later
				$pname = $unisender_SMS->name; // not really needed but may be later 
				$onclick = "resend_sms();";
				$send_to_multi = '0';
				
			} else {
			
				$mod_key_sing = $GLOBALS["beanList"][$_GET['ptype']];
				$mod_bean_files = $GLOBALS["beanFiles"][$mod_key_sing]; 
				
				# retrieve configured SMS phone field for the active module  
				require_once("modules/Administration/unisender_smsPhone/sms_enzyme.php");
				$e = new sms_enzyme($_GET['ptype']); 
				$sms_field = $e->get_custom_phone_field(); 
				
				$msg = "";
				$pid = $_GET['pid'];
				$pids = explode(",", $pid);
				$ptype = $_GET['ptype'];
				$pname = isset($_GET['pname']) ? $_GET['pname'] : "";
				$phone_number = $_GET['num'];
				$onclick = "send_sms();"; 
				$send_to_multi = $_GET['num'] == 'multi' ? '1' : '0';

			}
 			
			include_once("modules/Administration/unisender_smsPhone/sms_editor.php"); 
			
			break;
		/**/
		case "template":
			if (isset($_GET['id'])) {
				$et = new EmailTemplate();
				$et->retrieve($_GET['id']); 
				echo $et->body;
			}
			break;
			
		default:
			echo "";
	} 

// /$_GET['option']

} else  {	// just draw the gateway settings panel 

////////////////////////////////////////////////////////////////////////////////////////////////////////////
	 
	//include iz/sms_settings.inc.php

	SugarApplication::redirect('index.php?module=Configurator&action=unisender_config');

////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// show settings

	//include iz/sms_settings_show.inc.php
	
} 
?>