<script type="text/javascript" language="JavaScript" src="modules/Administration/unisender_smsPhone/javascript/jquery.js"></script> 
<script type="text/javascript" language="JavaScript" src="modules/Administration/unisender_smsPhone/javascript/jquery.jmpopups-0.5.1.js"></script>
<script type="text/javascript" language="JavaScript" src="modules/Administration/unisender_smsPhone/javascript/smsPhone.js"></script> 
<link rel="stylesheet" type="text/css" href="modules/Administration/unisender_smsPhone/style/smsPhone.css" />
 