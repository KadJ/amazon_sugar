<?php
function post_uninstall() {
	
	// nonupgradesafe

	// include/generic
   rename("include/generic/LayoutManager_old.php","include/generic/LayoutManager.php");
   // include/ListView
   rename("include/ListView/ListViewDisplay_old.php","include/ListView/ListViewDisplay.php");

   // nonupgradesafe - modules

   // modules/EmailMan
   rename("modules/EmailMan/EmailMan_old.php","modules/EmailMan/EmailMan.php");
   rename("modules/EmailMan/EmailManDelivery_old.php","modules/EmailMan/EmailManDelivery.php");

   // modules/Schedulers/languages
   // *
   	
	// nonupgradesafe2
	
   // modules/EmailTemplates
   /*
   rename("modules/EmailTemplates/EditView_old.php","modules/EmailTemplates/EditView.php");
   rename("modules/EmailTemplates/EditViewMain_old.html","modules/EmailTemplates/EditViewMain.html");
   rename("modules/EmailTemplates/DetailView_old.php","modules/EmailTemplates/DetailView.php");
   rename("modules/EmailTemplates/DetailView_old.html","modules/EmailTemplates/DetailView.html");
   rename("modules/EmailTemplates/EmailTemplate_old.js","modules/EmailTemplates/EmailTemplate.js");
   //
   rename("modules/EmailTemplates/metadata/searchdefs_old.php","modules/EmailTemplates/metadata/searchdefs.php");
   rename("modules/EmailTemplates/metadata/listviewdefs_old.php","modules/EmailTemplates/metadata/listviewdefs.php");
   */

}
post_uninstall();