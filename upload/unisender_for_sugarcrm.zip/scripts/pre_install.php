<?php
function pre_install() {
	
	// nonupgradesafe

	// include/generic
   copy("include/generic/LayoutManager.php","include/generic/LayoutManager_old.php");
   // include/ListView
   copy("include/ListView/ListViewDisplay.php","include/ListView/ListViewDisplay_old.php");

   // nonupgradesafe - modules

   // modules/EmailMan
   copy("modules/EmailMan/EmailMan.php","modules/EmailMan/EmailMan_old.php");
   copy("modules/EmailMan/EmailManDelivery.php","modules/EmailMan/EmailManDelivery_old.php");

   // modules/Schedulers/languages
   // *
   	
	// nonupgradesafe2

	// modules/EmailTemplates
   /*
   rename("modules/EmailTemplates/EditView.php","modules/EmailTemplates/EditView_old.php");
   rename("modules/EmailTemplates/EditViewMain.html","modules/EmailTemplates/EditViewMain_old.html");
   rename("modules/EmailTemplates/DetailView.php","modules/EmailTemplates/DetailView_old.php");
   rename("modules/EmailTemplates/DetailView.html","modules/EmailTemplates/DetailView_old.html");
   rename("modules/EmailTemplates/EmailTemplate.js","modules/EmailTemplates/EmailTemplate_old.js");
   //
   rename("modules/EmailTemplates/metadata/searchdefs.php","modules/EmailTemplates/metadata/searchdefs_old.php");
   rename("modules/EmailTemplates/metadata/listviewdefs.php","modules/EmailTemplates/metadata/listviewdefs_old.php");
   */
	
}
