<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.list.php');

class ContactsViewList extends ViewList
{
 	public function preDisplay() {
 		// Unisende-Suite-1.0
		require_once('custom/unisender/inc/header.all.php');
 		//
 		
		parent::preDisplay();
 		$this->lv->targetList = true;

 		// require_once('custom/unisender/inc/footer.all.php');
 	}
}
