<?php
# This module show an sms icon to phone numbers where a user can send sms
# Applicable to Detail View

function sms_phone($focus, $field, $value, $view) { 
  	global $beanList;
	$temp_field = $field;
	$phone_num = trim($focus->$temp_field); 
 	
	if($view == 'EditView' || $view == 'MassUpdate' || $view == 'QuickCreate') { //If this is EditView Or MassUpdate Include a field box 
	
		$phone_num = "<input type='text' name='{$field}' id='{$field}' value='{$phone_num}'>";
	
	} else { 
	
		if($focus->object_name == 'Case'){
				$ptype = 'Cases';
	        }else{
				$ptype = array_search($focus->object_name, $beanList);
	        }
		$pname = $focus->name;
		require_once("./modules/Administration/unisender_smsPhone/smsPhone.js.php");

		/**/global $app_strings;
		if (strlen(trim($phone_num))) 
 			$phone_num .= "&nbsp; <img style='border:none;cursor:pointer;' 
					title='".$app_strings['LBL_CLICK_TO_SEND_SMS']."'
					src='./modules/Administration/unisender_smsPhone/image/cellphone.gif' 
					onclick=\"openAjaxPopup('" . urlencode($phone_num). "','{$ptype}','{$focus->id}','{$pname}');\">";
	}
	return $phone_num;
}

?>
