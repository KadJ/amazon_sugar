<?php

// SaleScope.ru 0.1

interface um_interface_mail {
}