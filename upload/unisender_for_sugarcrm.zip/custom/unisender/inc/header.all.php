<?php

global $app_strings;

echo '<div>';
	echo '<a href="http://www.unisender.com/"><img src="http://www.unisender.com/common/img/logo_100_17.png" width="100" height="17" alt="' .$app_strings['LBL_UNISENDER_INC_ALT']. '" border="0"></a>';
	echo '&nbsp;';
	echo $app_strings['LBL_UNISENDER_INC_OPEN_ACCOUNT'] .' - <a href="http://cp.unisender.com/intro">cp.unisender.com/intro</a>. ' .$app_strings['LBL_UNISENDER_INC_REPLENISH_ACCOUNT']. ' - <a href="http://unisender.com/prices">unisender.com/prices</a>.';
echo '</div>';
//
echo '<div>';
	global $sugar_config;
	$list_transfer = $sugar_config['unisender_list_transfer'];
	if (empty($list_transfer)) {
  		SugarApplication::redirect('index.php?module=Configurator&action=unisender_config2');
	}
	echo $app_strings['LBL_UNISENDER_INC_INFO_ADD'] .' <a href="'.$site_url.'index.php?module=Configurator&action=unisender_config2">' .$app_strings['LBL_UNISENDER_INC_INFO_IN_SETTINGS']. '</a>.';
	echo '</br>';
	echo $app_strings['LBL_UNISENDER_INC_INFO_SEND'] .' <a href="'.$site_url.'index.php?module=Administration&action=customUsage">' .$app_strings['LBL_UNISENDER_INC_INFO_MODULE']. '</a>' .$app_strings['LBL_UNISENDER_INC_INFO_AND_ASSIGN']. '<a href="'.$site_url.'index.php?module=Administration&action=smsPhone">' .$app_strings['LBL_UNISENDER_INC_INFO_FIELDS']. '</a>' .$app_strings['LBL_UNISENDER_INC_INFO_FOR_SMS'];
echo '</div>';
