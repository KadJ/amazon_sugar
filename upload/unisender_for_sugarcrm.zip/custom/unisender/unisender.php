<?php
require_once ('unisender_api.php');

require_once ('um_interface.php');
require_once ('um_interface_mail.php');
require_once ('um_interface_sms.php');

// UniSender-Suite 1.0 2012-01-21
define("MSG_ERROR",'error');

define("DEBUG",FALSE);
define("TEST",FALSE);
//
define("VERBOSE",TRUE); // info in dialogs etc

//$log->fatal('custom/ ' . "@ " . __CLASS__ . ": " . __FUNCTION__ . ": " . __LINE__ . ' - $list' . $list);

class unisender extends UniSenderApi implements um_interface, um_interface_mail, um_interface_sms {

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public function authenticate () {
    //
    global $app_strings;
    //
    $ret = MSG_ERROR; //0;
    $result = $this->callMethod('getLists'); // ala authenticate
    //
    if ($result) {
      // Раскодируем ответ API-сервера
      $jsonObj = json_decode($result);

      if(null===$jsonObj) {
        // Ошибка в полученном ответе
        //echo "Invalid JSON";
      }
      
      elseif(!empty($jsonObj->error)) {
        // Ошибка получения перечня список
        //echo "An error occured: " . $jsonObj->error . "(code: " . $jsonObj->code . ")";

      } else {
        // Выводим коды и названия всех имеющихся списков
        //echo "Here's a list of your mailing lists:<br>";
        /*
        foreach ($jsonObj->result as $one) {
          echo "List #" . $one->id . " (" . $one->title . ")". "<br>";
        }
        */
        /*my*///echo 'Autheticated';
        $ret = 1;
      }
    } else {
      $app_strings['LBL_UNISENDER_API_ACCESS_ERROR'];
    }/* /result */
    return $ret;
  }/* /authenticate */

  public function getBalance () {
    //
    global $app_strings;
    //
    $ret = MSG_ERROR; //0;
    $result = $this->callMethod('getUserInfo'); // ala getBalance
    //
    if ($result) {
      // Раскодируем ответ API-сервера
      $jsonObj = json_decode($result);

      if(null===$jsonObj) {
        $app_strings['LBL_UNISENDER_INVALID_JSON'];
      }
      
      elseif(!empty($jsonObj->error)) {
        // Ошибка получения перечня список
        //echo "An error occured: " . $jsonObj->error . "(code: " . $jsonObj->code . ")";

      } else {
        if (DEBUG) {
          // Вывод некоторой информации о пользователе
          echo "User login: " . $jsonObj->result->login . "<br>";
          echo "Account owner: " . $jsonObj->result->master . "<br>";
          echo "User account balance: " . $jsonObj->result->balance . " " . $jsonObj->result->currency . "<br>";
        }//DEBUG
        //
        $ret = $jsonObj->result->balance;
      }
    } else {
      $app_strings['LBL_UNISENDER_API_ACCESS_ERROR'];
    }/* /result */
    return $ret;
  } /* /getBalance */

  //------------------------------------------------------------------------------------------------//
  
  // returns array of list titles/ids or error
  public function getLists () {
    //
    global $app_strings;
    //
    $ret = MSG_ERROR; //0;
    //
    $list = array();
    //
    $result = $this->callMethod('getLists');
    //
    if ($result) {
      // Раскодируем ответ API-сервера
      $jsonObj = json_decode($result);

      if(null===$jsonObj) {
        $app_strings['LBL_UNISENDER_INVALID_JSON'];
      }
      
      elseif(!empty($jsonObj->error)) {
        // Ошибка получения перечня список
        //echo "An error occured: " . $jsonObj->error . "(code: " . $jsonObj->code . ")";

      } else {
        // Выводим коды и названия всех имеющихся списков
        //echo "Here's a list of your mailing lists:<br>";
        foreach ($jsonObj->result as $one) {
          //echo "List #" . $one->id . " (" . $one->title . ")". "<br>";
        }
        $ret = $list;
      }
    } else {
      $app_strings['LBL_UNISENDER_API_ACCESS_ERROR'];
    }/* /result */
    //
    return $ret; // Array, elemtns: id=670832, title=test
  } /* /getLists */

  // returns array of list titles/ids or error
  public function getListsSelect () {
    //
    global $app_strings;
    //
    $ret = MSG_ERROR; //0;
    //
    $list = array();
    //
    $result = $this->callMethod('getLists');
    //
    if ($result) {
      // Раскодируем ответ API-сервера
      $jsonObj = json_decode($result);

      if(null===$jsonObj) {
        $app_strings['LBL_UNISENDER_INVALID_JSON'];
      }
      
      elseif(!empty($jsonObj->error)) {
        // Ошибка получения перечня список
        //echo "An error occured: " . $jsonObj->error . "(code: " . $jsonObj->code . ")";

      } else {
        // Выводим коды и названия всех имеющихся списков
        //echo "Here's a list of your mailing lists:<br>";
        foreach ($jsonObj->result as $one) {
          //echo "List #" . $one->id . " (" . $one->title . ")". "<br>";
          $list[$one->id] = $one->title; // diff here
        }
        $ret = $list;
      }
    } else {
      $app_strings['LBL_UNISENDER_API_ACCESS_ERROR'];
    }/* /result */
    //
    return $ret; // Array, elemtns: id=670832, title=test
  } /* /getLists */


  // params: $list_id - numeric
  // returnds list_id or FALSE
  public function isexistList ($list_id) {
    //
    global $app_strings;
    //
    $ret = FALSE; //0;
    //
    $result = $this->callMethod('getLists');
    //
    if ($result) {
      // Раскодируем ответ API-сервера
      $jsonObj = json_decode($result);

      if(null===$jsonObj) {
        // Ошибка в полученном ответе
        echo "Invalid JSON";
      }
      
      elseif(!empty($jsonObj->error)) {
        // Ошибка получения перечня список
        echo "An error occured: " . $jsonObj->error . "(code: " . $jsonObj->code . ")";

      } else {
        // Выводим коды и названия всех имеющихся списков
        //echo "Here's a list of your mailing lists:<br>";
        foreach ($jsonObj->result as $one) {
          //echo "List #" . $one->id . " (" . $one->title . ")". "<br>";
          //
          if ($one->id == $list_id) {
            $ret = $one->id;
          }
        }
        //
        //echo $ret;
      }
    } else {
      $app_strings['LBL_UNISENDER_API_ACCESS_ERROR'];
    }/* /result */
    //
    return $ret;
  } /* /isexistList */
    
  // ----------------------------------------------//

  // returns list id or error
  public function createList ($list) {
    //
    global $app_strings;
    //
    $ret = MSG_ERROR; //0;
    // Создаём POST-запрос
    // Если файл скрипта в кодировке UTF-8, то удалите вызов iconv
    $POST = array (
      'api_key' => $api_key,
      //'title' => iconv('cp1251', 'utf-8', $new_list_name)
      'title' => $list
    );

    // Устанавливаем соединение
    $result = $this->callMethod('createList',$POST);

  if ($result) {
    // Раскодируем ответ API-сервера
    $jsonObj = json_decode($result);

    if(null===$jsonObj) {
      // Ошибка в полученном ответе
      echo "Invalid JSON";

    }
    elseif(!empty($jsonObj->error)) {
      // Ошибка создания списка
      echo "An error occured: " . $jsonObj->error . "(code: " . $jsonObj->code . ")";

    } else {
      // Новый список успешно создан
      //echo "New list successfully created. List id is " . $jsonObj->result->id;
      $ret = $jsonObj->result->id;//success
    }
  } else {
    // Ошибка соединения с API-сервером
    echo "API access error";
  }
  return $ret;
  }/* /createList */

  //------------------------------------------------------------------------------------------------//

  // returns total or error
  public function importContacts ($contacts) {
    //
    global $app_strings;
    //
    $ret = MSG_ERROR; //0;
    //
    // Список, куда их добавить
    global $sugar_config;
    $list_id = $sugar_config['unisender_list_transfer']; // numeric
    //
    $id = $this->isexistList($list_id);
    if ((bool) $id) {
      //echo 'list is exist<br>';
      //echo 'Будет использован существующий список рассылки ' . $list . ' в Unisender.<br><br>';
    }
    else {
      //echo 'must be created<br>';
      $id = $this->createList($list_id); //Krumo($id);
      //echo 'Список рассылки <strong>' . $list . '</strong> создан в Unisender.<br><br>';
    }

    // Создаём POST-запрос
    $POST = array (
      //'api_key' => $this->ApiKey,
      'field_names[0]' => 'email',
      'field_names[1]' => 'Name',
      'field_names[2]' => 'email_status',
      'field_names[3]' => 'email_list_ids',
      'field_names[4]' => 'phone',
      'field_names[5]' => 'phone_status',
      'field_names[6]' => 'phone_list_ids',
    );
    
    //for ($i=0;$i<5;$i++){
    $i = 0;
    foreach ($contacts as $item) {
      $POST['data[' . $i .'][0]'] = $contacts[$i]['email'];
      $POST['data[' . $i .'][1]'] = $contacts[$i]['name']; //iconv('cp1251', 'utf-8', $contacts[$i]['name']);
      $POST['data[' . $i .'][2]'] = 'active';
      $POST['data[' . $i .'][3]'] = (string)$id;
      $POST['data[' . $i .'][4]'] = $contacts[$i]['phone'];
      $POST['data[' . $i .'][5]'] = 'active';
      $POST['data[' . $i .'][6]'] = (string)$id;
      ++$i;
    }

    $POST['double_optin'] = '1';
    //$POST['overwrite_lists'] = '1';

    // Устанавливаем соединение   
    if (TEST) {
      echo 'TEST: callMethod importContacts<br>';
    } else {
      $result = $this->callMethod('importContacts', $POST);
    }
    
    if ($result) {
      // Раскодируем ответ API-сервера
      $jsonObj = json_decode($result);

      if(null===$jsonObj) {
        $app_strings['LBL_UNISENDER_INVALID_JSON'];
      }
      elseif(!empty($jsonObj->error)) {
        // Ошибка импорта
        echo $app_strings['LBL_UNISENDER_ERROR_OCCURED'] .$jsonObj->error . "(code: " . $jsonObj->code . ")";

      } else {
        // "total":4, "inserted":2, "updated":1, "deleted":2, "new_emails":1,
        // Новые подписчики успешно добавлены
        //echo "Success! Added " . $jsonObj->result->new_emails . " new e-mail addresses";
        //
        if (DEBUG) {
          echo 'DEBUG importContacts(): total='.$jsonObj->result->total.', inserted='.$jsonObj->result->inserted.', updated='.$jsonObj->result->updated.', deleted='.$jsonObj->result->deleted.', new_emails='.$jsonObj->result->new_emails.'<br>';
        }
        /*
        $ret['total'] = $jsonObj->result->total;
        $ret['inserted'] = $jsonObj->result->inserted;
        $ret['updated'] = $jsonObj->result->updated;
        $ret['deleted'] = $jsonObj->result->deleted;
        $ret['new_emails'] = $jsonObj->result->new_emails;
        */
        $ret = $jsonObj->result->total;
      }

    } else {
      $app_strings['LBL_UNISENDER_API_ACCESS_ERROR'];
    }
    return $ret;
  } /* /importContacts */

  // ----------------------------------------------//

  // returns person_id or error
  public function subscribe ($contact) {
    //
    global $app_strings;
    //    
    $ret = MSG_ERROR; //0;
    //
    // Список, куда их добавить
    global $sugar_config;
    $list = $sugar_config['unisender_list_add'];

    global $log;

    //
    $id = $this->isexistList($list);
    // Krumo($id); // 667772 for test, FALSE for non-exist
    if ((bool) $id) {
      //echo 'list is exist<br>';
      //echo 'Будет использован существующий список рассылки ' . $list . ' в Unisender.<br><br>';
      $log->fatal("@ custom/unisender/unisender.php " . __CLASS__ . ":" . __LINE__ . " existed list $list");
    }
    else {
      //echo 'must be created<br>';
      $id = $this->createList($list);
      //Krumo($id);
      //echo 'Список рассылки <strong>' . $list . '</strong> создан в Unisender.<br><br>';
      $log->fatal("@ custom/unisender/unisender.php " . __CLASS__ . ":" . __LINE__ . " list created $list");
    }

    // Создаём POST-запрос
    $POST = array (
      //'api_key' => $this->ApiKey,
      'list_ids' => (string)$id,
      'fields[email]' => $contact['email'],
      'fields[Name]' => $contact['name'],
      'fields[email_status]' => 'active',
      'fields[phone]' => $contact['phone'],
      'fields[phone_status]' => 'active',
      //
      //'tags' => 'Added using SugarCRM Unisender Suite via -Contact-'
    );
    
    $POST['double_optin'] = '1';
    //$POST['overwrite_lists'] = '1';

    // Устанавливаем соединение   
    $result = $this->callMethod('subscribe', $POST);
    
    //Krumo($result);

    if ($result) {
      // Раскодируем ответ API-сервера
      $jsonObj = json_decode($result);

      if(null===$jsonObj) {
        $app_strings['LBL_UNISENDER_INVALID_JSON'];
      }
      elseif(!empty($jsonObj->error)) {
        // Ошибка добавления пользователя
        //echo "An error occured: " . $jsonObj->error . "(code: " . $jsonObj->code . ")";
        $log->fatal("@ custom/unisender/unisender.php " . __CLASS__ . ":" . __LINE__ . " An error occured error: $jsonObj->error code: $jsonObj->code");

      } else {
        
        // Новый пользователь успешно добавлен
        //echo "Added. ID is " . $jsonObj->result->person_id;
        $log->fatal("@ custom/unisender/unisender.php " . __CLASS__ . ":" . __LINE__ . " Added person_id $jsonObj->result->person_id");
        //
        $ret = $jsonObj->result->person_id;//success
      }

    } else {
      $app_strings['LBL_UNISENDER_API_ACCESS_ERROR'];
    }
    return $ret;
  } /* /subscribe */  

  //------------------------------------------------------------------------------------------------//
  // mail
  //------------------------------------------------------------------------------------------------//

  //------------------------------------------------------------------------------------------------//
  // sms
  //------------------------------------------------------------------------------------------------//

  public function sendSms ($phone_number, $message) {
    //
    global $app_strings;
    //
    $ret = MSG_ERROR; //0;
    //
    // Параметры сообщения
    $api_key = $this->ApiKey;
    //
    global $sugar_config;
    $sms_from = "";
    $sms_from = $sugar_config['unisender_sender'];
    if (empty($sms_from)) {
      SugarApplication::redirect('index.php?module=Configurator&action=unisender_config2');
    }
    //
    $sms_to = $phone_number;
    // Если скрипт в кодировке UTF-8, не используйте iconv
    //$sms_text = urlencode(iconv('cp1251', 'utf-8',"SMS-сообщение по-русски"));
    $sms_text = urlencode(iconv('cp1251', 'utf-8', $message));
    
    //
    // Создаём POST-запрос
    $POST = array (
      'api_key' => $api_key,
      'phone' => $sms_to,
      'sender' => $sms_from,
      'text' => $sms_text
    );
    //
    $result = $this->callMethod('sendSms', $POST);
    
    /// balance=0, TEST
    /// SMS message is sent. Message id 123_abcSMS cost is 0.5 RUB
    ///
    /// balance=0, ON
    /// An error occured: РћС‚РїСЂР°РІРєР° 1 sms СЃС‚РѕРёС‚ 0.98 СЂСѓР±.
    /// Р”Р»СЏ СЂР°СЃСЃС‹Р»РєРё Р’Р°Рј РЅРµРѕР±С…РѕРґРёРјРѕ РїРѕРїРѕР»РЅРёС‚СЊ СЃС‡С‘С‚ РєР°Рє РјРёРЅРёРјСѓРј РЅР° 0.98 СЂСѓР±.(code: not_enough_money)
    ///
    /// balance=0, OFF
    /// An error occured: AK100310-03 [api mode is off](code: access_denied)

    //
    if ($result) {
      // Раскодируем ответ API-сервера
      $jsonObj = json_decode($result);

      if(null===$jsonObj) {
        $app_strings['LBL_UNISENDER_INVALID_JSON'];

      }
      elseif(!empty($jsonObj->error)) {
        // Ошибка отправки сообщения //An error occured
        echo '</br><span style="color:red;">' .$app_strings['LBL_UNISENDER_ERROR_OCCURED_SMS'] .'</span></br>';
        //
        echo '- ' .$app_strings['LBL_UNISENDER_ERROR_MSG'] .$jsonObj->error .'</br>';
        echo '- ' .$app_strings['LBL_UNISENDER_ERROR_CODE'] .$jsonObj->code .'</br>';
      } else {
        // Сообщение успешно отправлено
        if (VERBOSE) {
          echo '<span style="color:blue;">' .$app_strings['LBL_UNISENDER_SMS_SENT'] .'</span></br>';
          echo '- ' .$app_strings['LBL_UNISENDER_SMS_ID'] .$jsonObj->result->sms_id .'<br>'; 
          echo '- ' .$app_strings['LBL_UNISENDER_SMS_COST'] .'<span style="color:green;">' .$jsonObj->result->price ." " .$jsonObj->result->currency .'</span></br>';
        }//VERBOSE
      }
    } else {
      echo $app_strings['LBL_UNISENDER_API_ACCESS_ERROR'];
    }
    //
    return $ret;
  } /* /sendSms */

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}/* /class unisender */
