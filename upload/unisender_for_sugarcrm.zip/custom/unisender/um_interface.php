<?php

// SaleScope.ru 0.1 

interface um_interface {
  public function authenticate();
  public function getBalance();
  //
  public function getLists();
  public function getListsSelect(); // for Sugar DropDown
  public function isexistList($list);
  public function createList($list);
  public function importContacts($contacts);
  public function subscribe($contact);
}