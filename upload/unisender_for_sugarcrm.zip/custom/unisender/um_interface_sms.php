<?php

// SaleScope.ru 0.1 

interface um_interface_sms {
  public function sendSms($phone_number, $message);
}