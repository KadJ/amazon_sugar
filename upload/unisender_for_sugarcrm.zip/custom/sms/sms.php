<?php
require_once ('./custom/sms/sms_interface.php');
//include_once("./modules/unisender_SMS/unisender_SMS.php"); // for DB

// UniSender-Suite 1.0
define("MSG_ERROR", 'error' );

// TEST
//require_once './custom/include/Krumo/class.krumo.php';

$sms_provider = 'unisender'; // = $sugar_config ['provider'] ['sms']; // or per user
$sms_provider_require = './custom/'.$sms_provider.'/'.$sms_provider.'.php';
require_once $sms_provider_require;

// send_message, resend calls send + db
// send, send_batch_message calls send_to_multi
// send_to_multi calls api
class sms implements sms_interface {
 
	//var $sms_center = "http://sms.*.com";
	//var $ismsc_auth = "/auth.php";  
	//var $ismsc_send_multi = "/sendToMulti.php";
	// var $config_file = "./custom/sms/sms_config.php";
	//var $sms_controller = "http://sms.*.com/sms_controller.php";
	//var $sms_controller_file = "/sms_controller.php";

	var $params = array();
	var $parent_type;
	var $parent_id;
	var $type;
	var $focus;
	var $response_text;

	/**/
	function __construct() {
    	$this->retrieve_settings();
    } /* /__construct */
	
	function retrieve_settings () {
		$this->params = array();
		/*
		if (file_exists($this->config_file)) {
			include($this->config_file);
			if (isset($sms_config)) {
				$this->params = $sms_config;
			}
		}
		*/
		global $sugar_config; //Krumo($sugar_config['unisender_api_key']);
		//
		//$this->params['sms_provider'] = $sms_provider;
		//
		$this->params['sms_instance_id'] = $sugar_config['unisender_api_key']; // $sugar_config['{$sms_provider}_api_key'];
		$this->params['sender'] = $sugar_config['unisender_sender']; //
		$this->params['default_country_code'] = '7'; // Russia
		//$this->params['local_prefix'] = '';
		$this->params['uses_sms_templates'] = FALSE; //TRUE
		//
	}/* /retrieve_setings */

	function save_settings () {
		/*
		include iz/sms1.inc.php
		*/
	}

	/* ala authenticate */
	function not_ready () {
		$empty = empty($sms->params['sms_instance_id']);
		return $empty;
	} /* /authenticate */
	
	// returns balance or 'error'
	function authenticate () {	
		//$this->retrieve_settings();
		$api_key = $this->params['sms_instance_id'];
		$api = new unisender($api_key); // $api = new $sms_provider($api_key);
		//
		$response = $api->getBalance(); // $sms_provider must support this method
		//
		return 	$response;
	} /* /authenticate */

	function authenticate_account ($account_id) {	
		// ex authenticate ($account_id)
	} /* /authenticate */
	  
	private function send($to, $text) {
		$pname = strlen($this->pname) ? $this->pname : "-no name-";
		$number[$to] = array($pname, $to);
		//
		$summary = $this->send_to_multi($number, $text);
		//
		$response['STATUS'] = $summary[$to]['delivery_status'];
		$response['API_MSG'] = $summary[$to]['api_message']; 
		return $response; 
	}
	
	function send_message($to,$text) {
	
		global $current_user;
		
		$to = preg_replace('/[^0-9]/', '', $to); 

		// service
		$response = $this->send($to, $text); 

		// db
		$unisender_SMS = new unisender_SMS();
		$unisender_SMS->provider = 'unisender';
		$unisender_SMS->description = $text;
		$unisender_SMS->api_message = $response['API_MSG'];  
		$unisender_SMS->delivery_status = $response['STATUS'];
		$unisender_SMS->parent_type = $this->parent_type;
		$unisender_SMS->parent_id = $this->parent_id;
		$unisender_SMS->name = strlen($this->pname) ? $this->pname : "-no name-";
		$unisender_SMS->name .= " (" . date("Y-m-d") . ")";
		$unisender_SMS->phone_number = strlen($to) ? $to." " : "-none-";
		$unisender_SMS->assigned_user_id = $current_user->id;
		$unisender_SMS->save();
		
		$this->response_text = $response['API_MSG'];
		return $this->response_text;
	}
	
	function resend($sms_id, $to, $text) { 
		global $current_user;

		$unisender_SMS = new unisender_SMS();
		$unisender_SMS->retrieve($sms_id);  
		if (isset($unisender_SMS->id) and !empty($unisender_SMS->id)) {
			$to = preg_replace('/[^0-9]/', '', $to);
			// service
			$response = $this->send($to, $text); 
			// db
			$unisender_SMS->phone_number = strlen($to) ? $to." " : "-none-";
			$unisender_SMS->description = $text;
			$unisender_SMS->api_message = $response['API_MSG'];  
			$unisender_SMS->delivery_status = $response['STATUS'];
			$unisender_SMS->type = "outbound";
			$unisender_SMS->save();
		} else {
			$this->response_text = "Javascript fault: Unable to send message.";
		} 
		$this->response_text = $response['API_MSG'];
		return $this->response_text;
	}
	
	/**
	send_to_multi
	**/
	private function send_to_multi($to_array, $text) {
		//echo "sms send_to_mult to_array text";
		// Krumo($to_array,$text);
		// ?
		foreach($to_array as $key => $to) {
			$to_array[$key] = $this->replace_local_prefix($to);
		}
		//Krumo($to_array);
	
		/*
		include iz/sms2.inc.php
		*/		

		//$this->retrieve_settings();
		$api_key = $this->params['sms_instance_id'];
		$api = new unisender($api_key); // $api = new $sms_provider($api_key);
		//$response = $api->sendSms($param_phone_number,$param_message);
		//

		foreach($to_array as $key => $to) {
			//	$to_array[$key] = $this->replace_local_prefix($to);
			$api->sendSms($to_array[$key][1],$to_Array[$key][0]);
		}

		//$phone = $to_array;
		//$api->sendSms($phone,$text);
		
	} /* /send_to_multi */
	
	# need to create batch sending on sms_provider
	function send_batch_message($to_array,$text) {
		global $current_user;
		
		$summary = $this->send_to_multi($to_array, $text); 
		
		if(!empty($summary['ERROR'])) {
			return $summary['ERROR']; 
		} 
		# save summary    
		if (sizeof($summary)) {
			foreach($summary as $pid => $val) { 
				$unisender_SMS = new unisender_SMS();
				$unisender_SMS->provider = $sms_provider; //'unisender';  
				$unisender_SMS->parent_type = $this->parent_type; 
				$unisender_SMS->description = $text;
				$unisender_SMS->api_message = $val["api_message"]; 
				$unisender_SMS->parent_id = $pid;
				$unisender_SMS->name = strlen($val["name"]) ? $val["name"] : "-no name-"; 
				$unisender_SMS->name .= " (" . date("Y-m-d") . ")";
				$unisender_SMS->phone_number = strlen($val['phone_number']) ? $val['phone_number']." " : "-none-";
				$unisender_SMS->assigned_user_id = $current_user->id;
				$unisender_SMS->delivery_status = $val["delivery_status"];  
				$unisender_SMS->save();
			}
		}  
		return $summary;
		 
	}
	
	function replace_local_prefix($to) {		
		# replaces the local prefix with the default country code
		if (!empty($this->params['default_country_code']) and strlen($this->params['default_country_code']) and isset($this->params['local_prefix']) and strlen($this->params['local_prefix'])) {
			$to = preg_replace("/^".$this->params['local_prefix']."/", $this->params['default_country_code'], $to);
		}
		return $to;
	
	}
	
	function uses_template() {
		$this->retrieve_settings();
		if(isset($this->params['uses_sms_template']))
			return $this->params['uses_sms_template'];
		else
			return false; // by default, SMS do not use templates
	}
	
	function get_supported_countries() {
	}
	
	function get_credit_usages() {
	}
 
}
?>
