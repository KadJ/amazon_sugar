<?php
$manifest = array (
	
	'acceptable_sugar_versions' => array(
		// 1 
		'exact_matches' => array(
			0 => "6.2.4",
		),
		// 2
		/*
		'regex_matches' => array(
	     	0 => "6.2.*",
	       	//1 => "6.3.*", // ?
	    ),
	    */
	),
	
	'acceptable_sugar_flavors' => array(
		'CE' /// ,'PRO', 'ENT'
	),
	
	//
	'readme'=>'',
	'icon' => '',
	
	//
	'key'=>'unisender',
	'author' => '800-CRM http://800-crm.ru',
	'description' => 	'Integration with UniSender.com',
	'version' => '1.0', 
	'name' => 'Unisender Suite 1.0',
	'published_date' => '19/01/2012 19:00:00',
	//
	'type' => 'module',
	'is_uninstallable' => true,
	'remove_tables' => 'prompt',
);
		  
		  
$installdefs = array(
  'id' => 'Unisender-Suite-1.0',

  // SugarModules/modules/unisender_SMS
  'beans' => array( 
    array(
      'module' => 'unisender_SMS',
      'class' => 'unisender_SMS',
      'path' => 'modules/unisender_SMS/unisender_SMS.php',
      'tab' => true,
    ),
  ),

  'layoutdefs' => array(
  ),
  
  'relationships' => array(
  ),
  
  'image_dir' => '<basepath>/icons',
  
  'copy' => array(

		/* custom classes */
		array(
			'from' => '<basepath>/custom/sms', /* SaleScope UM SMS 0.3 */
			'to' => 'custom/sms',
		),
		array(
			'from' => '<basepath>/custom/unisender', /* unisender_api 0.9 + SaleScope UM 0.3 */
			'to' => 'custom/unisender',
		),

		/* custom fields */
		array(
			'from' => '<basepath>/custom/fieldFormat/sms_phone_fields.php',
			'to' => 'custom/fieldFormat/sms_phone_fields.php',
		),

		/* SugarModules */
		array(
		  'from' => '<basepath>/SugarModules/modules/unisender_SMS', /* incl/ /language */
		  'to' => 'modules/unisender_SMS',
		),

		/* custom modules Ext */
		array(
			'from' => '<basepath>/custom/modules/Contacts', // views/* //6.2.x
			'to' => 'custom/modules/Contacts',
		),
		/* modules - upgradesafe */
		array(
			'from' => '<basepath>/upgradesafe/modules/Contacts/Save.php', // views
			'to' => 'modules/Contacts/Save.php',
		),

		/* include */
		array(
			'from' => '<basepath>/include/generic/SugarWidgets/SugarWidgetSubPanelSMSButton.php',
			'to' => 'include/generic/SugarWidgets/SugarWidgetSubPanelSMSButton.php',
		),
		/* include - nonupgradesafe */ 
		array(
			'from' => '<basepath>/nonupgradesafe/include/generic/6.2.4/LayoutManager.php', // generic/6.2.4/*
			'to' => 'include/generic/LayoutManager.php',
		), 
		array(
			'from' => '<basepath>/nonupgradesafe/include/ListView/6.2.4/ListViewDisplay.php', // ListView/6.2.4/*
			'to' => 'include/ListView/ListViewDisplay.php',
		),

		/* modules - nonupgradesafe */
		
		// Emailman
		array(
			'from' => '<basepath>/nonupgradesafe/modules/EmailMan/6.2.4/EmailMan.php',
			'to' => 'modules/EmailMan/EmailMan.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe/modules/EmailMan/6.2.4/EmailManDelivery.php',
			'to' => 'modules/EmailMan/EmailManDelivery.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe/modules/EmailMan/SMSManDelivery.php', // -iz
			'to' => 'modules/EmailMan/SMSManDelivery.php',
		),

		/* custom modules Ext */
		array(
			'from' => '<basepath>/custom/modules/Schedulers/_AddJobsHere.php', // require Emailman/SMSManDelivery.php
			'to' => 'custom/modules/Schedulers/_AddJobsHere.php',
		),

		/* modules - nonupgradesafe2 */

		// EmailTemplates
		/*
		array(
			'from' => '<basepath>/nonupgradesafe/modules/EmailTemplates/6.2.4/EditView.php', // HIDE_THIS
			'to' => 'modules/EmailTemplates/EditView.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe/modules/EmailTemplates/6.2.4/EditViewMain.html', // HIDE_THIS
			'to' => 'modules/EmailTemplates/EditViewMain.html',
		),
		array(
			'from' => '<basepath>/nonupgradesafe/modules/EmailTemplates/6.2.4/DetailView.php', // HIDE_THIS
			'to' => 'modules/EmailTemplates/DetailView.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe/modules/EmailTemplates/6.2.4/DetailView.html', // HIDE_THIS
			'to' => 'modules/EmailTemplates/DetailView.html',
		),
		array(
			'from' => '<basepath>/nonupgradesafe/modules/EmailTemplates/6.2.4/EmailTemplate.js', // js
			'to' => 'modules/EmailTemplates/EmailTemplate.js',
		),
		array(
			'from' => '<basepath>/nonupgradesafe/modules/EmailTemplates/metadata/6.2.4/searchdefs.php',
			'to' => 'modules/EmailTemplates/metadata/searchdefs.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe/modules/EmailTemplates/metadata/6.2.4/listviewdefs.php',
			'to' => 'modules/EmailTemplates/metadata/listviewdefs.php',
		),
		// Schedulers
		array(
			'from' => '<basepath>/nonupgradesafe/modules/Schedulers/language/6.2.4/en_us.lang.php',
			'to' => 'modules/Schedulers/language/en_us.lang.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe/modules/Schedulers/language/6.2.4/ru_ru.lang.php',
			'to' => 'modules/Schedulers/language/ru_ru.lang.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe/modules/Schedulers/language/6.2.4/it_it.lang.php',
			'to' => 'modules/Schedulers/language/it_it.lang.php',
		),

		/*

		/* modules - nonupgradesafe2 */

		/*
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/EmailMarketing/EditView.php',
			'to' => 'modules/EmailMarketing/EditView.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/EmailMarketing/EditView.html',
			'to' => 'modules/EmailMarketing/EditView.html',
		),
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/EmailMarketing/DetailView.php',
			'to' => 'modules/EmailMarketing/DetailView.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/EmailMarketing/DetailView.html',
			'to' => 'modules/EmailMarketing/DetailView.html',
		),
		// with lang
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/EmailMarketing/language/en_us.lang.php',
			'to' => 'modules/EmailMarketing/language/en_us.lang.php',
		),
		//
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/Campaigns/tpls/WizardHomeStart.tpl',
			'to' => 'modules/Campaigns/tpls/WizardHomeStart.tpl',
		), 
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/Campaigns/tpls/WizardCampaignTargetListForNonNewsLetter.tpl',
			'to' => 'modules/Campaigns/tpls/WizardCampaignTargetListForNonNewsLetter.tpl',
		),
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/Campaigns/views/view.detail.php',
			'to' => 'modules/Campaigns/views/view.detail.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/Campaigns/TrackDetailView.php',
			'to' => 'modules/Campaigns/TrackDetailView.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/Campaigns/WizardHome.php',
			'to' => 'modules/Campaigns/WizardHome.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/Campaigns/WizardMarketing.html',
			'to' => 'modules/Campaigns/WizardMarketing.html',
		),
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/Campaigns/WizardMarketing.php',
			'to' => 'modules/Campaigns/WizardMarketing.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/Campaigns/WizardNewsletter.php',
			'to' => 'modules/Campaigns/WizardNewsletter.php',
		),
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/Campaigns/QueueCampaign.php',
			'to' => 'modules/Campaigns/QueueCampaign.php',
		),
		// with lang
		array(
			'from' => '<basepath>/nonupgradesafe2/modules/Campaigns/language/en_us.lang.php',
			'to' => 'modules/Campaigns/language/en_us.lang.php', // inc en_us.sms_lang.php
		),
		*/
		

		/* Administration */
		array(
			'from' => '<basepath>/modules/Administration',
			'to' => 'modules/Administration',
		),
		/* Configurator */
		array(
			'from' => '<basepath>/modules/Configurator',
			'to' => 'modules/Configurator',
		),
		
  ), /* /copy */
  
  /* admin menu */
  'administration' => 
  array( 
    array(
       'from' => '<basepath>/Administration/unisender.ext.php',
    ),
  ),


  'language' => array( 
    
    /* application */
    array(
      'from' 		=> '<basepath>/SugarModules/language/application/en_us.lang.php',
      'to_module' 	=> 'application',
      'language' 	=> 'en_us',
    ),
    array(
      'from' 		=> '<basepath>/SugarModules/language/application/ru_ru.lang.php',
      'to_module' 	=> 'application',
      'language' 	=> 'ru_ru',
    ),
    array(
      'from' 		=> '<basepath>/SugarModules/language/application/it_it.lang.php',
      'to_module' 	=> 'application',
      'language' 	=> 'it_it',
    ),
    
    /* Administration */
    array(
      'from'      => '<basepath>/SugarModules/language/modules/Administration/en_us.unisender.php',
      'to_module' => 'Administration',
      'language'  => 'en_us',
    ),
    array(
      'from'      => '<basepath>/SugarModules/language/modules/Administration/ru_ru.unisender.php',
      'to_module' => 'Administration',
      'language'  => 'ru_ru',
    ),
    array(
      'from'      => '<basepath>/SugarModules/language/modules/Administration/it_it.unisender.php',
      'to_module' => 'Administration',
      'language'  => 'it_it',
    ),
    
    /* Configurator */
    array(
      'from'      => '<basepath>/SugarModules/language/modules/Configurator/en_us.unisender.php',
      'to_module' => 'Configurator',
      'language'  => 'en_us',
    ),
    array(
      'from'      => '<basepath>/SugarModules/language/modules/Configurator/ru_ru.unisender.php',
      'to_module' => 'Configurator',
      'language'  => 'ru_ru',
    ),
    array(
      'from'      => '<basepath>/SugarModules/language/modules/Configurator/it_it.unisender.php',
      'to_module' => 'Configurator',
      'language'  => 'it_it',
    ),

    /* Contacts */
    array(
      'from'      => '<basepath>/SugarModules/language/modules/Contacts/mod_strings_en_us.php',
      'to_module' => 'Contacts',
      'language'  => 'en_us',
    ),
    array(
      'from'      => '<basepath>/SugarModules/language/modules/Contacts/mod_strings_ru_ru.php',
      'to_module' => 'Contacts',
      'language'  => 'ru_ru',
    ),
    array(
      'from'      => '<basepath>/SugarModules/language/modules/Contacts/mod_strings_it_it.php',
      'to_module' => 'Contacts',
      'language'  => 'it_it',
    ),

    // EmailTemplates
	array(
      'from' 		=> '<basepath>/ext/Language/EmailTemplates/en_us.for_sms_lang.php',
      'to_module' 	=> 'EmailTemplates',
      'language' 	=> 'en_us',
    ),
    array(
      'from' 		=> '<basepath>/ext/Language/EmailTemplates/ru_ru.for_sms_lang.php',
      'to_module' 	=> 'EmailTemplates',
      'language' 	=> 'ru_ru',
    ),
    array(
      'from' 		=> '<basepath>/ext/Language/EmailTemplates/it_it.for_sms_lang.php',
      'to_module' 	=> 'EmailTemplates',
      'language' 	=> 'it_it',
    ),
    
    /* modules - nonupgradesafe2 */
    
    /*
    // ?
    array(
      'from' 		=> '<basepath>/ext/Language/Campaigns/en_us.sms_lang.php',
      'to_module' 	=> 'Campaigns',
      'language' 	=> 'en_us',
    ),
    array(
      'from' 		=> '<basepath>/ext/Language/Campaigns/ru_ru.sms_lang.php',
      'to_module' 	=> 'Campaigns',
      'language' 	=> 'ru_ru',
    ),
    */
  ),/* /language */

  /* modules - nonupgradesafe2 */

  /*
  'vardefs' => array(
     array(
       'from'		=> '<basepath>/ext/Vardefs/EmailTemplates/for_sms.php', 
       'to_module'	=> 'EmailTemplates',
     ),
	 array(
       'from'		=> '<basepath>/ext/Vardefs/Employees/sms_fields_for_employees.php', 
       'to_module'	=> 'Employees',
     ),
  ),
  */
	
	'post_uninstall' => array(
    	0 => '<basepath>/scripts/post_uninstall.php',
	),

);/* /manifest */