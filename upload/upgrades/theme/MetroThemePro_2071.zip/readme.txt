==============================
Metro Theme Pro

Instruction
==============================


Install Metro Theme Pro
=======================
Install theme using Module Loader. 
Install also Administration Module for  Metro Theme Pro  (MetroThemeProModule)


