<?php
$mod_strings['LBL_METROTHEMEPRO_TITLE'] = 'Metro Theme Pro';
$mod_strings['LBL_METROTHEMEPRO_ADMIN_DESC'] = 'Metro Theme Pro configuration';
$mod_strings['LBL_METROTHEMEPRO_CONFIG_TITLE'] = 'Settings';
$mod_strings['LBL_METROTHEMEPRO_CONFIG_INFO'] = 'Modify settings for theme features';
$mod_strings['LBL_MAXRELATED'] ='Maximum number of related items in preview';
$mod_strings['LBL_MAXNOTIFIC'] ='Maximum number of notifications';
$mod_strings['LBL_SHOWNOTIFIC'] ='Show notifications in the top menu';
$mod_strings['LBL_SHOWLOGO'] ='Show company logo in the top menu';
$mod_strings['LBL_SHOWPREVIEW'] ='Show preview in ListView';
$mod_strings['LBL_SHOWRELATED'] ='Show related records in preview';
$mod_strings['LBL_SHOWLOGOTRUE'] ='Show';
$mod_strings['LBL_SHOWLOGOFALSE'] ='Hide';
$mod_strings['LBL_SHOWTRUE'] ='yes';
$mod_strings['LBL_SHOWFALSE'] ='no';

?>


         