<?php  
$admin_option_defs = array();

$admin_option_defs['MetroThemePro_mod']['config'] = array('Easy_Theme', 'LBL_METROTHEMEPRO_CONFIG_TITLE', 'LBL_METROTHEMEPRO_CONFIG_INFO', './index.php?module=Administration&action=MetroThemePro_manage');


$admin_group_header[]= array('LBL_METROTHEMEPRO_TITLE', '', false, $admin_option_defs, 'LBL_METROTHEMEPRO_ADMIN_DESC');

