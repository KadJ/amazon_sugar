<?php
// Удаляем запись из планировщика
global $sugar_config;
$db = &DBManagerFactory::getInstance();
$job_name = $sugar_config['site_url'] . '/ts_check.php?from=scheduler';
$sql = "DELETE FROM `schedulers` WHERE `job` = '".$job_name."'";
$db->query($sql, true);