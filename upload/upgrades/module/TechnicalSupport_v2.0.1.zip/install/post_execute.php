<?php
include_once 'modules/lm_TechnicalSupport/lm_TechnicalSupport.php';
// Выполняем проверку связи с службой тех.поддержки
$seedTechnicalSupport = new lm_TechnicalSupport();
$seedTechnicalSupport->checkOnline();
