<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$smarty = new Sugar_Smarty();



$smarty->display("modules/lm_TechnicalSupport/tpls/About.tpl");